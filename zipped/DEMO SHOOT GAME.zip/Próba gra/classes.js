class Unit
{
    constructor(x,y,w,h,c)
    {
this.x=x;this.y=y;this.w=w;this.h=h;this.c=c;
    }
    draw=function(dx,dy)
    {
        ctx.fillStyle=this.c;
        ctx.fillRect(this.x-dx,this.y-dy,this.w,this.h);
    }
};

class Movable extends Unit
{
constructor(x,y,w,h,c,vx,vy)
{
    super(x,y,w,h,c);this.vx=vx;this.vy=vy;
}
move=function()
{
    this.x+=this.vx;this.y+=this.vy;
}
ondown=function(a)
{
    if(this.y+this.h<=a.y&&this.y+this.h+this.vy>a.y&&this.x+this.w-this.vx>a.x&&a.x+a.w>this.x-this.vx){this.canjump=true;this.y=a.y-this.h;this.vy=0;return true;}return false;
}
onup=function(a)
{
    if(a.y+a.h<=this.y&&a.y+a.h>this.y+this.vy&&this.x+this.w-this.vx>a.x&&a.x+a.w>this.x-this.vx){this.y=a.y+a.h;this.vy=0;return true;}return false;
}
onleft=function(a)
{
    if(a.x+a.w>this.x&&a.x+a.w<=this.x-this.vx&&this.y+this.h>a.y&&a.y+a.h>this.y){this.x=a.x+a.w;return true;}return false;
}
onright=function(a)
{
    if(this.x+this.w>a.x&&this.x+this.w-this.vx<=a.x&&this.y+this.h>a.y&&a.y+a.h>this.y){this.x=a.x-this.w;return true;}return false;
}
incenter=function(a)
{
    if(this.y+this.h>a.y&&a.y+a.h>this.y&&this.x+this.w>a.x&&a.x+a.w>this.x)return true;return false;
}

whendown=function(){;}
whenup=function(){;}
whenleft=function(){;}
whenright=function(){;}
};

class Bullet extends Movable
{
    constructor(x,y,w,h,c,vx,vy,str)
    {
        super(x,y,w,h,c,vx,vy);this.str=str
    }
}

class Walkable extends Movable
{
constructor(x,y,w,h,c,hp)
{
    super(x,y,w,h,c);this.vx=2;this.vy=0;this.dir='R';this.hp=hp;
}
move=function()
{
    this.x+=this.vx;this.y+=this.vy;this.vy+=0.05;
}
shoot=function()
{
    ;
}
};

class Enemy extends Walkable
{
    constructor(x,y,w,h,c,hp,vx,vy)
    {
        super(x,y,w,h,c,hp);this.vx=vx;this.vy=vy;
    }
    shoot=function(w)
{
    if(Math.random()<0.001){w.push(new Bullet(this.x+15,this.y+15,10,10,"green",4*(this.vx>0?1:-1),0,50));}
}
}

class Player extends Walkable
{
    constructor(x,y,w,h,c,hp,kl,kr,ku,ks)
    {
        super(x,y,w,h,c,hp);this.kl=kl;this.kr=kr;this.ku=ku;this.ks=ks;this.canjump=false;this.canshoot=true;this.dir='R';
    }
    move=function()
{
    if(gamekeys[this.kl]==true){this.vx=-2;this.dir='L';}else if(gamekeys[this.kr]==true){this.vx=2;this.dir='R'}else this.vx=0;
    if(gamekeys[this.ku]==true&&this.vy==0&&this.canjump){this.vy=-6;this.canjump=false;}
    this.x+=this.vx;this.y+=this.vy;this.vy+=0.05;
}
shoot=function(w)
{
    if(presseds[getcharc(this.ks)]==true&&this.canshoot){w.push(new Bullet(this.x+15,this.y+15,10,10,"orange",6*(this.dir=='R'?1:-1),0,50));this.canshoot=false;}
    if(presseds[getcharc(this.ks)]==false)this.canshoot=true;
}
}

class Grav extends Player
{
    constructor(x,y,w,h,c,hp,kl,kr,ku,kd,ks)
    {
        super(x,y,w,h,c,hp);this.kl=kl;this.kr=kr;this.ku=ku;this.kd=kd;this.ks=ks;this.canjump=false;this.canshoot=true;this.dir='R';this.g='D';
    }
    move=function()
{
    if(gamekeys[this.kl]==true){this.vx=-2;this.dir='L';}else if(gamekeys[this.kr]==true){this.vx=2;this.dir='R'}else this.vx=0;
    if(((gamekeys[this.ku]==true&&this.g=='D')||(gamekeys[this.kd]==true&&this.g=='U'))&&this.vy==0&&this.canjump){this.vy=-6*(this.g=='D'?1:-1);this.canjump=false;}
    if(gamekeys[this.ku]==false)this.canjump=true;
    this.x+=this.vx;this.y+=this.vy;this.vy+=0.05*(this.g=='D'?1:-1);
}

whendown=function(){this.g='D';if(gamekeys[this.ku]==true)this.canjump=false;}
whenup=function(){this.g='U';if(gamekeys[this.ku]==true)this.canjump=false;}
}