class Lvl
{
    constructor(obst,ienemy,bw,bh,hx,hy)
    {
        this.obst=obst;this.ienemy=ienemy;this.bw=bw;this.bh=bh;this.hx=hx;this.hy=hy;
    }
};

let lvls=[];
lvls=
[
new Lvl(
    [new Unit(0,858,1872,100,'ivory'),new Unit(0,758,100,100,'ivory'),new Unit(1772,758,100,100,'ivory')],
    [new Enemy(40,0,40,40,'chartreuse',100,1,0),new Enemy(40,0,40,40,'chartreuse',100,2,0),new Enemy(40,0,40,40,'chartreuse',100,3,0),new Enemy(40,0,40,40,'chartreuse',100,4,0)],
    1872,958,10,10
    ),
    new Lvl(
        [new Unit(0,1772,1872,100,'ivory'),new Unit(200,758,1672,100,'ivory'),new Unit(0,100,1672,100,'ivory'),new Unit(0,0,10,1872,'ivory'),new Unit(1862,0,10,1872,'ivory'),new Unit(1562,1472,100,100,'ivory')],
        [new Enemy(40,0,40,40,'chartreuse',100,1,0),new Enemy(40,0,40,40,'chartreuse',100,2,0),new Enemy(40,0,40,40,'chartreuse',100,3,0),new Enemy(40,0,40,40,'chartreuse',100,4,0)],
        1872,1872,1700,1700
        ),
        new Lvl(
            [new Unit(0,1772,1872,100,'ivory'),new Unit(1462,1272,100,100,'ivory'),new Unit(1562,1072,100,100,'ivory'),new Unit(0,0,10,1872,'ivory'),new Unit(1862,0,10,1872,'ivory'),new Unit(1562,1472,100,100,'ivory')],
            [new Enemy(40,0,40,40,'chartreuse',100,1,0),new Enemy(40,0,40,40,'chartreuse',100,2,0),new Enemy(40,0,40,40,'chartreuse',100,3,0),new Enemy(40,0,40,40,'chartreuse',100,4,0)],
            1872,1872,1700,1700
            ),
            new Lvl(
                [new Unit(10,300,40,600,'ivory'),new Unit(10,300,300,40,'ivory'),new Unit(280,300,40,300,'ivory'),new Unit(10,560,300,40,'ivory'),
                new Unit(370,300,40,600,'ivory'),new Unit(370,300,300,40,'ivory'),new Unit(370,860,300,40,'ivory'),new Unit(670,300,40,600,'ivory'),
                new Unit(760,860,300,40,'ivory'),new Unit(760,300,40,600,'ivory'),
                new Unit(1110,560,40,340,'ivory'),new Unit(1110,560,300,40,'ivory'),
                new Unit(1370,300,40,600,'ivory'),new Unit(1150,300,260,40,'ivory'),new Unit(1150,300,40,300,'ivory'),
                new Unit(1460,300,40,600,'ivory'),new Unit(1590,300,40,600,'ivory'),
                new Unit(1460,560,190,40,'ivory'),new Unit(1590,300,100,40,'ivory'),new Unit(1590,860,130,40,'ivory'),
                new Unit(10,1200,40,600,'ivory'),new Unit(270,1200,40,600,'ivory'),new Unit(10,1760,300,40,'ivory'),new Unit(140,1540,40,260,'ivory'),
                new Unit(360,1200,40,600,'ivory'),new Unit(360,1200,300,40,'ivory'),new Unit(360,1760,300,40,'ivory'),new Unit(360,1460,300,40,'ivory'),new Unit(560,1800,40,80,'ivory'),
                new Unit(710,1200,40,600,'ivory'),new Unit(710,1200,300,40,'ivory'),new Unit(710,1760,300,40,'ivory'),new Unit(810,1540,200,40,'ivory'),new Unit(970,1540,40,260,'ivory'),
                new Unit(1060,1200,40,600,'ivory'),
                new Unit(1150,1200,40,600,'ivory'),new Unit(1150,1200,300,40,'ivory'),new Unit(1150,1760,300,40,'ivory'),new Unit(1150,1460,300,40,'ivory'),
                new Unit(1500,1200,40,600,'ivory'),new Unit(1500,1200,290,40,'ivory'),new Unit(1500,1500,300,40,'ivory'),new Unit(1750,1200,40,300,'ivory'),new Unit(1700,1500,40,300,'ivory'),new Unit(1700,1760,300,40,'ivory'),],
                
                [new Enemy(40,0,40,40,'chartreuse',50,1,0),new Enemy(40,0,40,40,'chartreuse',50,2,0),new Enemy(40,0,40,40,'chartreuse',50,3,0),new Enemy(40,0,40,40,'chartreuse',50,4,0)],
                1872,1872,10,10
                ),
        new Lvl(
            [new Unit(0,300,1870,20,'ivory'),new Unit(0,500,1870,20,'ivory'),new Unit(0,300,20,220,'ivory'),new Unit(1850,300,20,220,'ivory')],
            [new Enemy(1800,400,60,60,'gold',1000,-4,0)],
            1872,958,40,400
        ),
        new Lvl(
            [new Unit(0,0,1872,40,'ivory'),new Unit(0,918,1872,40,'ivory'),new Unit(0,0,40,958,'ivory'),new Unit(1832,0,40,958,'ivory'),new Unit(200,200,1472,558,'ivory'),],
            [new Enemy(1800,400,60,60,'gold',1000,-4,0),new Enemy(1800,400,60,60,'gold',1000,-4,0),new Enemy(1800,400,60,60,'gold',1000,-4,0),new Enemy(1800,400,60,60,'gold',1000,-4,0)],
            1872,958,40,400
        )
];

