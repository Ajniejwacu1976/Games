const canvas=document.getElementById("canvas");
const ctx=canvas.getContext("2d");



let obst=[new Unit(0,858,2072,100,'ivory'),new Unit(0,758,100,100,'ivory'),new Unit(1972,758,100,100,'ivory')];
let player=new Player(0,10,40,40,'crimson',100,0,1,2,' ');
let camX=10,camY=10;let BW=2072;let BH=958;
let bord=[new Unit(BW,0,100,BH,"orange"),new Unit(0,BH,BW,100,"orange")];
let bullet=[];
let ienemy=[new Enemy(40,0,40,40,'chartreuse',100,1,0),new Enemy(40,0,40,40,'chartreuse',100,2,0),new Enemy(40,0,40,40,'chartreuse',100,3,0),new Enemy(40,0,40,40,'chartreuse',100,4,0)];
let enemy=[];
let ebullet=[];
let waitforenemy=400;let clvl=0;let pltype=0;let gamestatus=-2;

let generate;

function go()
{
    if(gamestatus==-2)
    {
        beforegame(ctx);
        if(presseds[getcharc('SHIFT')]==true)
        {gamestatus=0;generate(0);}
        return;
    }
waitforenemy--;
if(waitforenemy==0)
{
    waitforenemy=400;if(ienemy.length!=0)
    {
    enemy.push(ienemy[0]);
    ienemy.shift();
    }
}




    if(player.x<window.innerWidth/2)camX=0;
    else if(player.x>BW-window.innerWidth/2)camX=BW-window.innerWidth;
    else
    {
        camX=player.x-(window.innerWidth)/2;
    }
    if(player.y<window.innerHeight/2)camY=0;
    else if(player.y>BH-window.innerHeight/2)camY=BH-window.innerHeight;
    else
    {
        camY=player.y-(window.innerHeight)/2;
    }
for(let i in obst)
obst[i].draw(camX,camY);
for(let i in bord)
bord[i].draw(camX,camY);
if(player.hp>0)
{
player.draw(camX,camY);
player.move();
player.shoot(bullet);
}
else
{
    gamestatus=-1;
    ctx.font="40px verdana";
    ctx.fillStyle="red";
    ctx.fillText("실패",200,40);
}
for(let i in obst)
{
    player.onright(obst[i]);player.onleft(obst[i]);
    if(player.onup(obst[i]))player.whenup();if(player.ondown(obst[i]))player.whendown();
}
for(let i in obst)
{
    for(let j in bullet)
    {
if(bullet[j].onleft(obst[i])){bullet.splice(j,1);continue;}
if(bullet[j].onright(obst[i])){bullet.splice(j,1);continue;}
    }
}

for(let i in obst)
{
    for(let j in ebullet)
    {
if(ebullet[j].onleft(obst[i])){ebullet.splice(j,1);continue;}
if(ebullet[j].onright(obst[i])){ebullet.splice(j,1);continue;}
    }
}

for(let i in ebullet)
{
    ebullet[i].draw(camX,camY);ebullet[i].move();
    if(ebullet[i].incenter(player)){player.hp-=ebullet[i].str;ebullet.splice(i,1);}
}

for(let i in bullet)
{bullet[i].draw(camX,camY);bullet[i].move()}

for(let i in enemy)
{
    if(enemy[i].hp<=0||enemy[i].y>BH){enemy.splice(i,1);continue;}
    enemy[i].draw(camX,camY);
    enemy[i].move();
    enemy[i].shoot(ebullet)
}
for(let i in obst)
{
    for(let j in enemy)
    {
if(enemy[j].onleft(obst[i]))enemy[j].vx*=(-1);
if(enemy[j].onright(obst[i]))enemy[j].vx*=(-1);
enemy[j].onup(obst[i]);
enemy[j].ondown(obst[i]);
    }
}


for(let j in enemy)
{
    for(let i in bullet)
    {
        if(
bullet[i].onright(enemy[j])||bullet[i].onleft(enemy[j])||bullet[i].incenter(enemy[j])
        )
        {
enemy[j].hp-=bullet[i].str;bullet.splice(i,1);
        }
    }
}

if(enemy.length==0&&ienemy.length==0)
{
    console.log('Victory!');gamestatus=1;
    ctx.font="40px verdana";
ctx.fillStyle="lime";
ctx.fillText("승리",200,40);
}

ctx.font="40px verdana";
ctx.fillStyle="black";
ctx.fillText(country[clvl],20,40);

if(presseds[getcharc('ESCAPE')]&&gamestatus!=1)generate(clvl);
if(presseds[getcharc('SHIFT')]&&gamestatus==1)generate(++clvl);

}

window.setInterval(()=>{canvas.width=window.innerWidth;canvas.height=window.innerHeight;go()},1);


generate=function(lv)
{
    gamestatus=0;
    obst=[];
for(let i in lvls[lv].obst)
obst[i]=lvls[lv].obst[i];
ienemy=[];
for(let i in lvls[lv].ienemy)
{
ienemy.push(new Enemy(lvls[lv].ienemy[i].x,lvls[lv].ienemy[i].y,lvls[lv].ienemy[i].w,lvls[lv].ienemy[i].h,lvls[lv].ienemy[i].c,lvls[lv].ienemy[i].hp,lvls[lv].ienemy[i].vx,lvls[lv].ienemy[i].vy));
}
BW=lvls[lv].bw;BH=lvls[lv].bh;
switch(pltype)
{
case 0:player=new Player(lvls[lv].hx,lvls[lv].hy,40,40,'crimson',100,0,1,2,' ');break;
case 1:player=new Grav(lvls[lv].hx,lvls[lv].hy,40,40,'crimson',100,0,1,2,3,' ');break;
}
enemy=[];waitforenemy=400;
ebullet=[];
bord=[new Unit(BW,0,100,BH,"orange"),new Unit(0,BH,BW,100,"orange")];
clvl=lv;
}