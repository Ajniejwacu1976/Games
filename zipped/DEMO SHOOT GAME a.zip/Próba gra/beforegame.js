function beforegame(ctx)
{
    ctx.font="40px verdana";
    ctx.fillStyle="black";
    ctx.fillText("SHIFT를 눌러 게임을 시작하세요.",0,40);
}