class Unit
{
    constructor(x,y,w,h,c='ivory')
    {
this.x=x;this.y=y;this.w=w;this.h=h;this.c=c;
    }
    draw=function(dx,dy)
    {
        ctx.fillStyle=this.c;
        ctx.fillRect(this.x-dx,this.y-dy,this.w,this.h);
    }
};

class Movable extends Unit
{
constructor(x,y,w,h,c,vx,vy)
{
    super(x,y,w,h,c);this.vx=vx;this.vy=vy;
}
move=function()
{
    this.x+=this.vx;this.y+=this.vy;
}
ondown=function(a)
{
    if(this.y+this.h<=a.y&&this.y+this.h+this.vy>a.y&&this.x+this.w-this.vx>a.x&&a.x+a.w>this.x-this.vx){this.y=a.y-this.h;this.vy=0;return true;}return false;
}
onup=function(a)
{
    if(a.y+a.h<=this.y&&a.y+a.h>this.y+this.vy&&this.x+this.w-this.vx>a.x&&a.x+a.w>this.x-this.vx){this.y=a.y+a.h;this.vy=0;return true;}return false;
}
onleft=function(a)
{
    if(a.x+a.w>this.x&&a.x+a.w<=this.x-this.vx&&this.y+this.h+this.vy-0.05>a.y&&a.y+a.h>this.y){this.x=a.x+a.w;return true;}return false;
}
onright=function(a)
{
    if(this.x+this.w>a.x&&this.x+this.w-this.vx<=a.x&&this.y+this.h+this.vy-0.05>a.y&&a.y+a.h>this.y){this.x=a.x-this.w;return true;}return false;
}
incenter=function(a)
{
    if(this.y+this.h>a.y&&a.y+a.h>this.y&&this.x+this.w>a.x&&a.x+a.w>this.x)return true;return false;
}

whendown=function(){;}
whenup=function(){;}
whenleft=function(){;}
whenright=function(){;}
whencent=function(a)
{
    let dv=Math.abs((this.y+this.h/2)-(a.y-a.h/2));
    let dh=Math.abs((this.x+this.w/2)-(a.x-a.w/2));
    if(dv<dh)
    {
    if(this.y+this.h/2<a.y+a.h/2){this.y=a.y-this.h;}else this.y=a.y+a.h;
    this.vy=0;
    }
    else
    {
        if(this.x+this.w/2<a.x+a.w/2){this.x=a.x-this.w;}else this.x=a.x+a.w;
    }
}
};

class Bullet extends Movable
{
    constructor(x,y,w,h,c,vx,vy,str)
    {
        super(x,y,w,h,c,vx,vy);this.str=str
    }
}

class Parabolic extends Bullet
{
    constructor(x,y,w,h,c,vx,vy,str)
    {
        super(x,y,w,h,c,vx,vy,str)
    }
    move=function()
{
    this.x+=this.vx;this.y+=this.vy;this.vy+=0.05;
}
}

class Walkable extends Movable
{
constructor(x,y,w,h,c,hp)
{
    super(x,y,w,h,c);this.vx=2;this.vy=0;this.dir='R';this.hp=hp;
}
move=function()
{
    this.x+=this.vx;this.y+=this.vy;this.vy+=0.05;
}
shoot=function()
{
    ;
}
};

/////////////////////Enemies

class Enemy extends Walkable
{
    constructor(x,y,w,h,c,hp,vx,vy)
    {
        super(x,y,w,h,c,hp);this.vx=vx;this.vy=vy;
    }
    shoot=function(w)
{
    if(Math.random()<0.001){w.push(new Bullet(this.x+15,this.y+15,10,10,"green",4*(this.vx>0?1:-1),0,50));}
}
}

class Downup extends Enemy
{
    constructor(x,y,w,h,c,hp,vx,vy)
    {
        super(x,y,w,h,c,hp,vx,vy);this.g='D';
    }
    whendown=function(){this.g='U';}
    whenup=function(){this.g='D';}
    move=function()
    {
        this.x+=this.vx;this.y+=this.vy;if(this.g=='D')this.vy+=0.05;else this.vy-=0.05;
    }
}

class Obojniak extends Enemy
{
    constructor(x,y,w,h,c,hp,vx,vy,en)
    {
        super(x,y,w,h,c,hp,vx,vy);this.en=en;
    }
    shoot=function(w)
{
    if(Math.random()<0.02){this.en.push(new Enemy(this.x-20,this.y-20,40,40,'chartreuse',100,(this.vx>0?1:-1),6));}
}
}

/////////////////////Players

class Player extends Walkable
{
    constructor(x,y,w,h,c,hp,kl,kr,ku,ks)
    {
        super(x,y,w,h,c,hp);this.kl=kl;this.kr=kr;this.ku=ku;this.ks=ks;this.canjump=false;this.canshoot=true;this.dir='R';
    }
    move=function()
{
    if(gamekeys[this.kl]==true){this.vx=-2;this.dir='L';}else if(gamekeys[this.kr]==true){this.vx=2;this.dir='R'}else this.vx=0;
    if(gamekeys[this.ku]==true&&this.vy==0&&this.canjump){this.vy=-6;this.canjump=false;}
    if(gamekeys[this.ku]==false&&this.vy==0){this.canjump=true;}
    this.x+=this.vx;this.y+=this.vy;this.vy+=0.05;
}
shoot=function(w)
{
    if(presseds[getcharc(this.ks)]==true&&this.canshoot){w.push(new Bullet(this.x+15,this.y+15,10,10,"orange",6*(this.dir=='R'?1:-1),0,50));this.canshoot=false;}
    if(presseds[getcharc(this.ks)]==false)this.canshoot=true;
}
}

class Grav extends Player
{
    constructor(x,y,w,h,c,hp,kl,kr,ku,kd,ks)
    {
        super(x,y,w,h,c,hp);this.kl=kl;this.kr=kr;this.ku=ku;this.kd=kd;this.ks=ks;this.canjump=false;this.canshoot=true;this.dir='R';this.g='D';
    }
    move=function()
{
    if(gamekeys[this.kl]==true){this.vx=-2;this.dir='L';}else if(gamekeys[this.kr]==true){this.vx=2;this.dir='R'}else this.vx=0;
    if(((gamekeys[this.ku]==true&&this.g=='D')||(gamekeys[this.kd]==true&&this.g=='U'))&&this.vy==0&&this.canjump){this.vy=-6*(this.g=='D'?1:-1);this.canjump=false;}
    if(gamekeys[this.ku]==false)this.canjump=true;
    this.x+=this.vx;this.y+=this.vy;this.vy+=0.05*(this.g=='D'?1:-1);
}

whendown=function(){this.g='D';if(gamekeys[this.ku]==true)this.canjump=false;}
whenup=function(){this.g='U';if(gamekeys[this.ku]==true)this.canjump=false;}
}

class Spark extends Player
{
    constructor(x,y,w,h,c,hp,kl,kr,ku,ks)
    {
        super(x,y,w,h,c,hp);this.kl=kl;this.kr=kr;this.ku=ku;this.ks=ks;this.canjump=false;this.canshoot=true;this.dir='R';
    }
    shoot=function(w)
{
    if(presseds[getcharc(this.ks)]==true&&this.canshoot){w.push(new Parabolic(this.x+15,this.y+15,10,10,"orange",-2,-6,50));w.push(new Parabolic(this.x+15,this.y+15,10,10,"orange",2,-6,50));
    w.push(new Parabolic(this.x+15,this.y+15,10,10,"orange",-1,-4,50));w.push(new Parabolic(this.x+15,this.y+15,10,10,"orange",1,-4,50));this.canshoot=false;}
    if(presseds[getcharc(this.ks)]==false)this.canshoot=true;
}
}

class Climber extends Player
{
    constructor(x,y,w,h,c,hp,kl,kr,ku,ks)
    {
        super(x,y,w,h,c,hp);this.kl=kl;this.kr=kr;this.ku=ku;this.ks=ks;this.canjump=false;this.canshoot=true;this.dir='R';
    }
whenleft=function(){this.canjump=true;}
whenright=function(){this.canjump=true;}
move=function()
{
    this.x+=this.vx;this.y+=this.vy;this.vy+=0.05;
    if(gamekeys[this.kl]==true){this.vx=-2;this.dir='L';}else if(gamekeys[this.kr]==true){this.vx=2;this.dir='R'}else this.vx=0;
    if(gamekeys[this.ku]==true&&this.canjump){this.vy=-6;this.canjump=false;}

}
}





















//////////////////TEST

class Anotherr
{
    constructor(arg)
    {
        this.arg=arg;
    }
    func=function()
    {
        this.arg.push(1);
    }
}

let aa=[1,2,3,4,5,6];
let cc=[new Anotherr(aa)];
aa.push(cc[0]);
let bb=new Anotherr(aa);
bb.func();