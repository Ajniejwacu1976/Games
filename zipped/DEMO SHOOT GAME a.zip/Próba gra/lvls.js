class Lvl
{
    constructor(obst,ienemy,bw,bh,hx,hy)
    {
        this.obst=obst;this.ienemy=ienemy;this.bw=bw;this.bh=bh;this.hx=hx;this.hy=hy;
    }
};

let lvls=[];
lvls=
[
new Lvl(
    [new Unit(0,858,1872,100),new Unit(0,758,100,100),new Unit(1772,758,100,100)],
    [new Enemy(40,0,40,40,'chartreuse',100,1,0),new Enemy(40,0,40,40,'chartreuse',100,2,0),new Enemy(40,0,40,40,'chartreuse',100,3,0),new Enemy(40,0,40,40,'chartreuse',100,4,0)],
    1872,958,10,10
    ),
    new Lvl(
        [new Unit(0,1772,1872,100),new Unit(200,758,1672,100),new Unit(0,100,1672,100),new Unit(0,0,10,1872),new Unit(1862,0,10,1872),new Unit(1562,1472,100,100)],
        [new Enemy(40,0,40,40,'chartreuse',100,1,0),new Enemy(40,0,40,40,'chartreuse',100,2,0),new Enemy(40,0,40,40,'chartreuse',100,3,0),new Enemy(40,0,40,40,'chartreuse',100,4,0)],
        1872,1872,1700,1700
        ),
        new Lvl(
            [new Unit(0,1772,1872,100),new Unit(1462,1272,100,100),new Unit(1562,1072,100,100),new Unit(0,0,10,1872),new Unit(1862,0,10,1872),new Unit(1562,1472,100,100)],
            [new Enemy(40,0,40,40,'chartreuse',100,1,0),new Enemy(40,0,40,40,'chartreuse',100,2,0),new Enemy(40,0,40,40,'chartreuse',100,3,0),new Enemy(40,0,40,40,'chartreuse',100,4,0)],
            1872,1872,1700,1700
            ),
            new Lvl(
                [new Unit(10,300,40,600),new Unit(10,300,300,40),new Unit(280,300,40,300),new Unit(10,560,300,40),
                new Unit(370,300,40,600),new Unit(370,300,300,40),new Unit(370,860,300,40),new Unit(670,300,40,600),
                new Unit(760,860,300,40),new Unit(760,300,40,600),
                new Unit(1110,560,40,340),new Unit(1110,560,300,40),
                new Unit(1370,300,40,600),new Unit(1150,300,260,40),new Unit(1150,300,40,300),
                new Unit(1460,300,40,600),new Unit(1590,300,40,600),
                new Unit(1460,560,190,40),new Unit(1590,300,100,40),new Unit(1590,860,130,40),
                new Unit(10,1200,40,600),new Unit(270,1200,40,600),new Unit(10,1760,300,40),new Unit(140,1540,40,260),
                new Unit(360,1200,40,600),new Unit(360,1200,300,40),new Unit(360,1760,300,40),new Unit(360,1460,300,40),new Unit(560,1800,40,80),
                new Unit(710,1200,40,600),new Unit(710,1200,300,40),new Unit(710,1760,300,40),new Unit(810,1540,200,40),new Unit(970,1540,40,260),
                new Unit(1060,1200,40,600),
                new Unit(1150,1200,40,600),new Unit(1150,1200,300,40),new Unit(1150,1760,300,40),new Unit(1150,1460,300,40),
                new Unit(1500,1200,40,600),new Unit(1500,1200,290,40),new Unit(1500,1500,300,40),new Unit(1750,1200,40,300),new Unit(1700,1500,40,300),new Unit(1700,1760,300,40),],
                
                [new Enemy(40,0,40,40,'chartreuse',50,1,0),new Enemy(40,0,40,40,'chartreuse',50,2,0),new Enemy(40,0,40,40,'chartreuse',50,3,0),new Enemy(40,0,40,40,'chartreuse',50,4,0)],
                1872,1872,10,10
                ),
        new Lvl(
            [new Unit(0,300,1870,20),new Unit(0,500,1870,20),new Unit(0,300,20,220),new Unit(1850,300,20,220)],
            [new Enemy(1800,400,60,60,'gold',1000,-4,0)],
            1872,958,40,400
        ),
        new Lvl(
            [new Unit(0,0,1872,40),new Unit(0,918,1872,40),new Unit(0,0,40,958),new Unit(1832,0,40,958),new Unit(200,200,1472,558),],
            [new Enemy(1800,400,60,60,'gold',1000,-4,0),new Enemy(1800,400,60,60,'gold',1000,-4,0),new Enemy(1800,400,60,60,'gold',1000,-4,0),new Enemy(1800,400,60,60,'gold',1000,-4,0)],
            1872,958,40,400
        ),
        new Lvl(
[new Unit(0,3000,1000,40),new Unit(200,200,40,2800),new Unit(2760,200,40,2800),new Unit(2000,3000,1000,40),
new Unit(1300,3000,400,40),new Unit(200,200,1000,40,),new Unit(400,500,2400,40,),new Unit(2600,2800,200,40),new Unit(400,400,40,100,),],
[new Enemy(2000,0,40,40,'chartreuse',200,-2,0)],
3000,3200,1400,2900
        ),
        new Lvl(
            [new Unit(0,2000,1920,40),new Unit(0,1960,40,80),new Unit(1880,1960,40,80),
            new Unit(0,0,1920,40),new Unit(760,200,400,1800),new Unit(660,1800,600,40),],
            [new Enemy(200,200,40,40,'blueviolet',10,1,1),new Enemy(1200,200,40,40,'blueviolet',10,-1,1),new Enemy(200,200,40,40,'blueviolet',10,1,1),new Enemy(1200,200,40,40,'blueviolet',10,-1,1),
            new Enemy(200,200,40,40,'blueviolet',10,1,1),new Enemy(1200,200,40,40,'blueviolet',10,-1,1),new Enemy(200,200,40,40,'blueviolet',10,1,1),new Enemy(1200,200,40,40,'blueviolet',10,-1,1),
            new Enemy(200,200,40,40,'blueviolet',10,1,1),new Enemy(1200,200,40,40,'blueviolet',10,-1,1),new Enemy(200,200,40,40,'blueviolet',10,1,1),new Enemy(1200,200,40,40,'blueviolet',10,-1,1),
            new Enemy(200,200,40,40,'blueviolet',10,1,1),new Enemy(1200,200,40,40,'blueviolet',10,-1,1),new Enemy(200,200,40,40,'blueviolet',10,1,1),new Enemy(1200,200,40,40,'blueviolet',10,-1,1),],
            1920,2040,926,100
        ),
        new Lvl(
[new Unit(0,0,2000,40),new Unit(0,0,40,2000),new Unit(0,1960,2000,40),
new Unit(1960,0,40,2000),new Unit(0,200,200,1600),new Unit(1800,200,200,1600),
new Unit(980,1100,40,900),new Unit(980,0,40,900),new Unit(600,800,40,40),
new Unit(600,1160,40,40),new Unit(1360,800,40,40),new Unit(1360,1160,40,40)],
[new Downup(1400,100,40,40,'chartreuse',600,-2,1),new Downup(1400,100,40,40,'chartreuse',600,2,1),new Downup(1400,100,40,40,'chartreuse',600,-2,1),new Downup(1400,100,40,40,'chartreuse',600,2,1),
new Downup(1400,100,40,40,'gold',200,-4,1),new Downup(1400,100,40,40,'gold',200,4,1),new Downup(1400,100,40,40,'gold',200,-4,1),new Downup(1400,100,40,40,'gold',200,4,1)],
2000,2000,100,100
        ),
        new Lvl(
            [new Unit(0,700,1000,20),new Unit(0,420,20,300),new Unit(980,690,20,10),new Unit(2100,700,200,20),new Unit(3200,600,1000,20),new Unit(4180,300,20,300),new Unit(3200,590,20,10),],
            [new Enemy(0,0,20,20,'chartreuse',100,2,2),new Enemy(0,0,40,40,'chartreuse',100,2,2),new Enemy(0,0,20,20,'chartreuse',100,2,2),new Enemy(0,0,40,40,'chartreuse',100,2,2),new Enemy(0,0,20,20,'chartreuse',100,2,2),new Enemy(0,0,40,40,'chartreuse',100,2,2),
            new Enemy(0,0,20,20,'chartreuse',100,2,2),new Enemy(0,0,20,20,'chartreuse',100,2,2),new Enemy(0,0,20,20,'chartreuse',100,2,2),new Enemy(0,0,20,20,'chartreuse',100,2,2),
            new Enemy(0,0,20,20,'chartreuse',100,2,2),new Enemy(0,0,20,20,'chartreuse',100,2,2),new Enemy(0,0,20,20,'chartreuse',100,2,2),new Enemy(0,0,20,20,'chartreuse',100,2,2),],
            4200,958,2200,0
        ),
        new Lvl(
            [new Unit(0,0,1872,40),new Unit(0,0,40,958),new Unit(1832,0,40,808),new Unit(0,918,1872,40),
                new Unit(200,478,1672,40),new Unit(0,719,100,239),new Unit(1772,239,100,239),new Unit(1872,958,1722,40),
                new Unit(1872,958,40,958),new Unit(1872,1876,1872,40),new Unit(3704,958,40,808),new Unit(2072,1436,1672,40),
                new Unit(1872,1675,100,239),new Unit(3644,1197,100,239),new Unit(3744,1916,40,958),new Unit(3744,1916,1672,40),
                new Unit(5576,1916,40,808),new Unit(3744,2834,1872,40),new Unit(5515,2155,100,239),new Unit(3944,2394,1672,40),
                new Unit(3744,2633,100,239),new Unit(5616,2874,1672,40),new Unit(5616,2874,40,958),new Unit(7448,2874,40,958),
                new Unit(5616,3792,1872,40),new Unit(7388,3113,100,239),new Unit(5616,3591,100,239),new Unit(5816,3352,1672,40),new Unit(4000,400,40,40),],
                [new Enemy(100,100,40,40,'chartreuse',100,2,2)],
                7488,3832,4000,0
        ),
        new Lvl(
            [new Unit(736,400,400,40),new Unit(736,360,40,80),new Unit(1096,360,40,80)],
            [new Enemy(936,300,40,40,'gold',1000,2,2)],
            1872,958,936,100
        ),
        new Lvl(
            [new Unit(100,400,200,40),new Unit(100,400,40,400),new Unit(100,760,200,40),new Unit(300,440,40,320),new Unit(400,400,40,400),new Unit(400,400,140,40),new Unit(500,400,40,400),new Unit(500,760,140,40),new Unit(600,400,40,400),new Unit(700,400,240,40),new Unit(700,580,240,40),new Unit(700,760,240,40),new Unit(700,400,40,180),new Unit(900,580,40,180),new Unit(1000,400,240,40),new Unit(1000,580,240,40),new Unit(1000,760,240,40),new Unit(1000,400,40,180),new Unit(1200,580,40,180),new Unit(300,1000,40,400),new Unit(300,1000,150,40),new Unit(300,1180,240,40),new Unit(300,1360,240,40),new Unit(410,1000,40,200),new Unit(500,1180,40,200),new Unit(600,1000,240,40),new Unit(600,1360,240,40),new Unit(700,1000,40,400),new Unit(900,1000,240,40),new Unit(900,1180,240,40),new Unit(900,1360,240,40),new Unit(900,1000,40,180),new Unit(1100,1180,40,180),new Unit(1200,1000,40,400),new Unit(1200,1000,240,40),new Unit(1200,1180,240,40),new Unit(1400,1000,40,200),new Unit(1320,1180,40,220),new Unit(1320,1360,120,40),new Unit(1300,760,240,40),new Unit(1300,560,40,200),new Unit(1500,560,40,200),],
            [new Obojniak(0,0,80,80,'gold',1000,2,2,incoming)],
            1872,2000,200,200
        ),
        new Lvl(
            [new Unit(669,0,100,2500),new Unit(1069,0,100,2500),new Unit(669,0,500,100),new Unit(869,200,100,100),new Unit(869,400,100,100),new Unit(869,600,100,100),new Unit(869,800,100,100),new Unit(869,1000,100,100),new Unit(869,1200,100,100),new Unit(869,1400,100,100),new Unit(869,1600,100,100),new Unit(869,1800,100,100),new Unit(869,2000,100,100),new Unit(869,2200,100,100),new Unit(669,2400,500,100),],
            [new Downup(880,100,40,40,'pink',1000,2,2)],
            1872,2500,880,2300
        ),
];
