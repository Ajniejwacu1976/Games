

const shot=document.getElementById('shot');
const born=document.getElementById('born');
const victory=document.getElementById('vic');
const defeat=document.getElementById('def');
const killeden=document.getElementById('killed');
