const
cPol=0,
cNet=1,
cDen=2,
cSer=3,
cBul=4,
cHun=5,
cUkr=6,
cRom=7,
cLit=8,
cLat=9,
cEst=10,
cGeo=11,
cFin=12,
cSwe=13,
cSvk=14,
cCan=15,
cFra=16,
cIta=17,
cGbr=18,
cSau=19,
cIrn=20,
cKzk=21,
cAph=22,
cJap=23,
cSko=24,
cTha=25,
cVie=26,
cNko=27,
cChi=28,
cBlr=29,
cRus=30,
cUsa=31,
Mac=32;


country=
[
    "Polska","Holandia","Dania","Serbia",
    "Bułgaria","Węgry","Ukraina","Rumunia",
    "Litwa","Łotwa","Estonia","Gruzja",
    "Finlandia","Szwecja","Słowacja","Kanada",
    "Francja","Włochy","Wielka Brytania","Arabia Saudyjska",
    "Iran","Kazachstan","Afganistan","Japonia",
    "Korea Południowa","Tajlandia","Wietnam","Korea Północna",
    "Chiny","Białoruś","Rosja","Stany Zjednoczone",

    "Zemsta Cotangensa",
];



function pythagoras(fx,fy,lx,ly)
{
    return Math.sqrt(Math.pow(Math.abs(fx-lx),2)+Math.pow(Math.abs(fy-ly),2));
}

function randfrom(min,max)
{
    let base=Math.random()*max;
    if(base<min)return min;return base;
}


