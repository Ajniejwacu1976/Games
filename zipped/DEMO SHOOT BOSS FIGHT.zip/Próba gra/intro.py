****************************
*                          *
*       Introduction       *
*                          *
****************************

	I am really glad that you are reading this text.
	I created this game as an answer on older one: "Reksio i Kretes: tajemnica trzeciego wymiaru" released in 2007 by Aidem Media. One of its creators was Krzysztof Hrynkiewicz. I wrote this application for him.
	The aim of this game is obvious: kill all enemies. You move the character by using KEYS WITH ARROWS. Use SPACE to shoot. Use ENTER to restart.
	If you want to choose any level:
	1.Press ESC to open main menu.
	2.Use keys with arrows to choose a country.
	3.Press ENTER to confirm your choice.
	4.Press ESC to play.