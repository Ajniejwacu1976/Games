class Unit
{
    constructor(x,y,w,h,c='ivory')
    {
this.x=x;this.y=y;this.w=w;this.h=h;this.c=c;
    }
    draw=function(dx,dy)
    {
        ctx.fillStyle=this.c;
        ctx.fillRect(this.x-dx,this.y-dy,this.w,this.h);
    }
};

class Movable extends Unit
{
constructor(x,y,w,h,c,vx,vy)
{
    super(x,y,w,h,c);this.vx=vx;this.vy=vy;
}

pwd=function(a)
{
    this.y=a.y-this.h;this.vy=0;
}
pwu=function(a)
{
    this.y=a.y+a.h;this.vy=0;
}
pwl=function(a)
{
    this.x=a.x+a.w;
}
pwr=function(a)
{
    this.x=a.x-this.w;
}

move=function()
{
    this.x+=this.vx;this.y+=this.vy;
}
ondown=function(a)
{
    if(this.y+this.h<=a.y&&this.y+this.h+this.vy>a.y&&this.x+this.w-this.vx>a.x&&a.x+a.w>this.x-this.vx){return true;}return false;
}
onup=function(a)
{
    if(a.y+a.h<=this.y&&a.y+a.h>this.y+this.vy&&this.x+this.w-this.vx>a.x&&a.x+a.w>this.x-this.vx){return true;}return false;
}
onleft=function(a)
{
    if(a.x+a.w>this.x&&a.x+a.w<=this.x-this.vx&&this.y+this.h+this.vy-0.05>a.y&&a.y+a.h>this.y){return true;}return false;
}
onright=function(a)
{
    if(this.x+this.w>a.x&&this.x+this.w-this.vx<=a.x&&this.y+this.h+this.vy-0.05>a.y&&a.y+a.h>this.y){return true;}return false;
}
incenter=function(a)
{
    if(this.y+this.h>a.y&&a.y+a.h>this.y&&this.x+this.w>a.x&&a.x+a.w>this.x){
        if(this.y+this.h>a.y&&this.vy<0&&this.y<a.y)return false;
        if(a.y+a.h>this.y&&this.vy>0&&this.y>a.y)return false;
        return true;}return false;
}

/*
incenter=function(a)
{
    if(this.y+this.h>a.y&&a.y+a.h>this.y&&this.x+this.w>a.x&&a.x+a.w>this.x)return true;return false;
}
*/

whendown=function(){;}
whenup=function(){;}
whenleft=function(){;}
whenright=function(){;}
whencent=function(a)
{
    let dv=Math.abs((this.y+this.h/2)-(a.y-a.h/2));
    let dh=Math.abs((this.x+this.w/2)-(a.x-a.w/2));
    if(dv<dh)
    {
    if(this.y+this.h/2<a.y+a.h/2){this.y=a.y-this.h;}else this.y=a.y+a.h;
    this.vy=0;
    }
    else
    {
        if(this.x+this.w/2<a.x+a.w/2){this.x=a.x-this.w;}else this.x=a.x+a.w;
    }
}
};

class Bullet extends Movable
{
    constructor(x,y,w,h,c,vx,vy,str,hitimm=false)
    {
        super(x,y,w,h,c,vx,vy);this.str=str;this.hitimm=hitimm
    }
}

class Parabolic extends Bullet
{
    constructor(x,y,w,h,c,vx,vy,str,hitimm)
    {
        super(x,y,w,h,c,vx,vy,str,hitimm)
    }
    move=function()
{
    this.x+=this.vx;this.y+=this.vy;this.vy+=0.05;
}
}

class Homing extends Bullet
{
    constructor(x,y,w,h,c,vx,vy,str,en,hitimm)
    {
        super(x,y,w,h,c,vx,vy,str,hitimm),this.en=en;
    }
    move=function()
    {
        if(this.en.length==0){;return;}
        let closest=0;
        let nrcl=0;
        for(let i in this.en)
        {
            let ld=pythagoras(this.x+this.w/2,this.y+this.h/2,this.en[i].x+this.en[i].w/2,this.en[i].y+this.en[i].h/2);
            if(i==0)
            {
                closest=ld;
                continue;
            }
            
            if(closest>ld){closest=ld;nrcl=i;}
        }
let uangle=Math.atan2((this.en[nrcl].y+this.en[nrcl].h/2)-(this.y+this.h/2),(this.en[nrcl].x+this.en[nrcl].w/2)-(this.x+this.w/2));
this.vx=Math.cos(uangle);this.vy=Math.sin(uangle);this.x+=this.vx;this.y+=this.vy;
    }
}

class Tang extends Bullet
{
    constructor(x,y,w,h,c,vx,vy,str,hitimm)
    {
        super(x,y,w,h,c,vx,vy,str,hitimm);this.initx=x;this.inity=y;
    }
    move=function()
    {
        this.x+=this.vx;
        this.y=this.inity+Math.tan(((this.initx-this.x)*Math.PI/180)*0.2);
    }
}

class Cosinus extends Bullet
{
    constructor(x,y,w,h,c,vx,vy,str,hitimm)
    {
        super(x,y,w,h,c,vx,vy,str,hitimm);this.initx=x;this.inity=y;
    }
    move=function()
    {
        this.x+=this.vx;
        this.y=this.inity+Math.cos(((this.initx-this.x)*Math.PI/180))*20;
    }
}


////////////////////////////////

class Walkable extends Movable
{
constructor(x,y,w,h,c,hp)
{
    super(x,y,w,h,c);this.vx=2;this.vy=0;this.dir='R';this.hp=hp;
}
move=function()
{
    this.x+=this.vx;this.y+=this.vy;this.vy+=0.05;
}
shoot=function()
{
    ;
}
};

/////////////////////Enemies

class Enemy extends Walkable
{
    constructor(x,y,w,h,c,hp,vx,vy,ondie=function(){killeden.play();})
    {
        super(x,y,w,h,c,hp);this.vx=vx;this.vy=vy;this.mhp=hp;this.ondie=ondie;
    }
    shoot=function(w)
{
    if(Math.random()<0.001){w.push(new Bullet(this.x+15,this.y+15,10,10,"green",4*(this.vx>0?1:-1),0,50));}
}
draw=function(dx,dy)
{
    ctx.fillStyle=this.c;
    ctx.fillRect(this.x-dx,this.y-dy,this.w,this.h);
    ctx.fillStyle='black';
    ctx.fillRect(this.x-dx,this.y-dy+this.h+4,this.h,4);
    ctx.fillStyle='red';
    ctx.fillRect(this.x-dx,this.y-dy+this.h+4,this.h*(this.hp/this.mhp),4);
}
dead=function()
{
    this.ondie();
}
}

class Downup extends Enemy
{
    constructor(x,y,w,h,c,hp,vx,vy,ondie=function(){killeden.play();})
    {
        super(x,y,w,h,c,hp,vx,vy,ondie);this.g='D';
    }
    whendown=function(){this.g='U';}
    whenup=function(){this.g='D';}
    move=function()
    {
        this.x+=this.vx;this.y+=this.vy;if(this.g=='D')this.vy+=0.05;else this.vy-=0.05;
    }
}

class Obojniak extends Enemy
{
    constructor(x,y,w,h,c,hp,vx,vy,en,min=1,max=1,ondie=function(){killeden.play();})
    {
        super(x,y,w,h,c,hp,vx,vy,ondie);this.en=en;this.min=min;this.max=max;
    }
    shoot=function(w)
{
    if(Math.random()<0.01){this.en.push(new Enemy(this.x+20,this.y+20,40,40,'chartreuse',100,(this.vx>0?1:-1)*randfrom(this.min,this.max),-6));appeareden++;allen++;born.play();}
}
}

class Aimer extends Enemy
{
    constructor(x,y,w,h,c,hp,vx,vy,ang,bt,ondie=function(){killeden.play();})
    {
        super(x,y,w,h,c,hp,vx,vy,ondie);this.time=bt;this.ang=ang;this.bt=bt;this.cang=ang
    }
    shoot=function(w)
    {
        if(this.time==0)
        {
            w.push(new Bullet(this.x+this.w/2,this.y+this.w/2,10,10,'purple',Math.cos(this.ang/180*Math.PI)*6,Math.sin(this.ang/180*Math.PI)*6,50,true));this.ang+=this.cang*2;
            if(this.ang>360)this.ang=this.cang;this.time=this.bt;
        }
        else this.time--;
    }
}

class Tangensoide extends Enemy
{
    constructor(x,y,w,h,c,hp,vx,vy,ondie=function(){killeden.play();})
    {
        super(x,y,w,h,c,hp,vx,vy,ondie);
    }
    shoot=function(w)
    {
        if(Math.random()<0.001){w.push(new Tang(this.x+15,this.y+15,10,10,"green",0.5*(this.vx>0?1:-1),0,50));}
    }
}

/////////////////////Players

class Player extends Walkable
{
    constructor(x,y,w,h,c,hp,kl,kr,ku,ks,att=50)
    {
        super(x,y,w,h,c,hp);this.kl=kl;this.kr=kr;this.ku=ku;this.ks=ks;this.canjump=false;this.canshoot=true;this.dir='R';this.att=att;
    }
    move=function()
{
    if(gamekeys[this.kl]==true){this.vx=-2;this.dir='L';}else if(gamekeys[this.kr]==true){this.vx=2;this.dir='R'}else this.vx=0;
    if(gamekeys[this.ku]==true&&this.vy==0&&this.canjump){this.vy=-6;this.canjump=false;}
    if(gamekeys[this.ku]==false&&this.vy==0){this.canjump=true;}
    this.x+=this.vx;this.y+=this.vy;this.vy+=0.05;
}
shoot=function(w)
{
    if(presseds[getcharc(this.ks)]==true&&this.canshoot){w.push(new Bullet(this.x+15,this.y+15,10,10,"orange",6*(this.dir=='R'?1:-1),0,this.att));this.canshoot=false;shot.play();}
    if(presseds[getcharc(this.ks)]==false)this.canshoot=true;
}
}

class Grav extends Player
{
    constructor(x,y,w,h,c,hp,kl,kr,ku,kd,ks,att=50)
    {
        super(x,y,w,h,c,hp,kl,kr,ku,ks,att);this.kl=kl;this.kr=kr;this.ku=ku;this.kd=kd;this.ks=ks;this.canjump=false;this.canshoot=true;this.dir='R';this.g='D';
    }
    move=function()
{
    if(gamekeys[this.kl]==true){this.vx=-2;this.dir='L';}else if(gamekeys[this.kr]==true){this.vx=2;this.dir='R'}else this.vx=0;
    if(((gamekeys[this.ku]==true&&this.g=='D')||(gamekeys[this.kd]==true&&this.g=='U'))&&this.vy==0&&this.canjump){this.vy=-6*(this.g=='D'?1:-1);this.canjump=false;}
    if(gamekeys[this.ku]==false)this.canjump=true;
    this.x+=this.vx;this.y+=this.vy;this.vy+=0.05*(this.g=='D'?1:-1);
}

whendown=function(){this.g='D';if(gamekeys[this.ku]==true)this.canjump=false;}
whenup=function(){this.g='U';if(gamekeys[this.ku]==true)this.canjump=false;}
}

class Spark extends Player
{
    constructor(x,y,w,h,c,hp,kl,kr,ku,ks,att=50)
    {
        super(x,y,w,h,c,hp,kl,kr,ku,ks,att);this.kl=kl;this.kr=kr;this.ku=ku;this.ks=ks;this.canjump=false;this.canshoot=true;this.dir='R';
    }
    shoot=function(w)
{
    if(presseds[getcharc(this.ks)]==true&&this.canshoot){w.push(new Parabolic(this.x+15,this.y+15,10,10,"orange",-2,-6,this.att));w.push(new Parabolic(this.x+15,this.y+15,10,10,"orange",2,-6,this.att));
    w.push(new Parabolic(this.x+15,this.y+15,10,10,"orange",-1,-4,this.att));w.push(new Parabolic(this.x+15,this.y+15,10,10,"orange",1,-4,this.att));this.canshoot=false;shot.play();}
    if(presseds[getcharc(this.ks)]==false)this.canshoot=true;
}
}

class Climber extends Player
{
    constructor(x,y,w,h,c,hp,kl,kr,ku,ks,att=50)
    {
        super(x,y,w,h,c,hp,kl,kr,ku,ks,att);this.kl=kl;this.kr=kr;this.ku=ku;this.ks=ks;this.canjump=false;this.canshoot=true;this.dir='R';
    }
whenleft=function(){this.canjump=true;}
whenright=function(){this.canjump=true;}
whendown=function(){this.canjump=true;}
move=function()
{
    this.y+=this.vy;this.vy+=0.05;
    if(gamekeys[this.kl]==true){this.vx=-2;this.dir='L';}else if(gamekeys[this.kr]==true){this.vx=2;this.dir='R'}else this.vx=0;
    if(gamekeys[this.ku]==true&&this.canjump){this.vy=-6;this.canjump=false;}
    this.x+=this.vx;

}
}

class Cztery extends Player
{
    constructor(x,y,w,h,c,hp,kl,kr,ku,ks,en,att=1)
    {
        super(x,y,w,h,c,hp,kl,kr,ku,ks,att);this.kl=kl;this.kr=kr;this.ku=ku;this.ks=ks;this.canjump=false;this.canshoot=true;this.dir='R';this.en=en;
    }
    shoot=function(w)
    {
        if(presseds[getcharc(this.ks)]==true&&this.canshoot){
for(let i in this.en)
{
    this.en[i].hp-=this.att;
}this.canshoot=false;shot.play();
        }
        if(presseds[getcharc(this.ks)]==false)this.canshoot=true;
    }   
}

class Wind extends Player
{
    constructor(x,y,w,h,c,hp,kl,kr,ku,ks,en,att=10)
    {
        super(x,y,w,h,c,hp,kl,kr,ku,ks,att);this.kl=kl;this.kr=kr;this.ku=ku;this.ks=ks;this.canjump=false;this.canshoot=true;this.dir='R';this.en=en;
    }
    shoot=function(w)
    {
        if(presseds[getcharc(this.ks)]==true&&this.canshoot){w.push(new Homing(this.x+15,this.y+15,10,10,'orange',0,2,this.att,this.en));this.canshoot=false;shot.play();}
        if(presseds[getcharc(this.ks)]==false)this.canshoot=true;
    }
}

















//////////////////BOSS

class SuperCotangens extends Enemy
{
    constructor(x,y,w,h,c,hp,vx,vy,ondie=function(){killeden.play();},enemy,ienemy,pl)
    {
        super(x,y,w,h,c,hp);
        this.vx=vx;this.vy=vy;this.mhp=hp;this.en=enemy;this.ien=ienemy;this.eb=[];this.ondie=function(){console.log(this.eb);killed+=this.en.length-1;allen-=this.ien.length;this.eb.splice(0,this.eb.length);this.en.splice(1,this.en.length);this.ien.splice(0,this.ien.length);};
        this.pl=pl;this.g='D';
    }
    shoot=function(w)
    {
        this.eb=w;
        if(Math.random()<0.004)
        {
            if(this.hp>9000)
            {w.push(new Bullet(this.x+15,this.y+(this.w-15)/2,10,10,"green",0.5*(this.vx>0?1:-1),0,50));
        w.push(new Bullet(this.x+105,this.y+(this.w-15)/2,10,10,"green",0.5*(this.vx>0?1:-1),0,50));
        w.push(new Cosinus(this.x+(this.w-10)/2,this.y+(this.w-10)/2,10,10,"green",(this.vx>0?1:-1),0,50));
    }
    else if(this.hp>7000)
    {
            w.push(new Parabolic(this.x+(this.w-10)/2,this.y+(this.w-10)/2,10,10,"green",(Math.random()-0.5)*10,Math.random()*-10,50));
            w.push(new Parabolic(this.x+(this.w-10)/2,this.y+(this.w-10)/2,10,10,"green",(Math.random()-0.5)*10,Math.random()*-10,50));
            w.push(new Parabolic(this.x+(this.w-10)/2,this.y+(this.w-10)/2,10,10,"green",(Math.random()-0.5)*10,Math.random()*-10,50));
            w.push(new Parabolic(this.x+(this.w-10)/2,this.y+(this.w-10)/2,10,10,"green",(Math.random()-0.5)*10,Math.random()*-10,50));
    }
            else if(this.hp>5000)
            {
        w.push(new Bullet(this.x+(this.w-10)/2,this.y+(this.w-10)/2,10,10,"green",1,0,50));
        w.push(new Bullet(this.x+(this.w-10)/2,this.y+(this.w-10)/2,10,10,"green",-1,0,50));
        w.push(new Bullet(this.x+(this.w-10)/2,this.y+(this.w-10)/2,10,10,"green",0,1,50));
        w.push(new Bullet(this.x+(this.w-10)/2,this.y+(this.w-10)/2,10,10,"green",0,-1,50));
        w.push(new Bullet(this.x+(this.w-10)/2,this.y+(this.w-10)/2,10,10,"green",-1,1,50));
        w.push(new Bullet(this.x+(this.w-10)/2,this.y+(this.w-10)/2,10,10,"green",-1,-1,50));
        w.push(new Bullet(this.x+(this.w-10)/2,this.y+(this.w-10)/2,10,10,"green",1,1,50));
        w.push(new Bullet(this.x+(this.w-10)/2,this.y+(this.w-10)/2,10,10,"green",1,-1,50));
    }
    else if(this.hp<1000)
    {
        appeareden++;allen++;born.play();
this.en.push(new Obojniak(this.x+this.w/2-40,this.y+this.h/2-40,80,80,'gold',10,Math.random()-0.5,Math.random(),this.en));
    }
    else if(this.hp<2000)
            {
        w.push(new Bullet(this.x+(this.w-10)/2,this.y+(this.w-10)/2,10,10,"green",1,0,50));
        w.push(new Bullet(this.x+(this.w-10)/2,this.y+(this.w-10)/2,10,10,"green",-1,0,50));
        w.push(new Bullet(this.x+(this.w-10)/2,this.y+(this.w-10)/2,10,10,"green",0,1,50));
        w.push(new Bullet(this.x+(this.w-10)/2,this.y+(this.w-10)/2,10,10,"green",0,-1,50));
        w.push(new Bullet(this.x+(this.w-10)/2,this.y+(this.w-10)/2,10,10,"green",-1,1,50));
        w.push(new Bullet(this.x+(this.w-10)/2,this.y+(this.w-10)/2,10,10,"green",-1,-1,50));
        w.push(new Bullet(this.x+(this.w-10)/2,this.y+(this.w-10)/2,10,10,"green",1,1,50));
        w.push(new Bullet(this.x+(this.w-10)/2,this.y+(this.w-10)/2,10,10,"green",1,-1,50));

        w.push(new Bullet(this.x+(this.w-10)/2,this.y+(this.w-10)/2,10,10,"green",0.5,1,50));
        w.push(new Bullet(this.x+(this.w-10)/2,this.y+(this.w-10)/2,10,10,"green",0.5,-1,50));
        w.push(new Bullet(this.x+(this.w-10)/2,this.y+(this.w-10)/2,10,10,"green",-0.5,1,50));
        w.push(new Bullet(this.x+(this.w-10)/2,this.y+(this.w-10)/2,10,10,"green",-0.5,-1,50));
        w.push(new Bullet(this.x+(this.w-10)/2,this.y+(this.w-10)/2,10,10,"green",1,-0.5,50));
        w.push(new Bullet(this.x+(this.w-10)/2,this.y+(this.w-10)/2,10,10,"green",-1,-0.5,50));
        w.push(new Bullet(this.x+(this.w-10)/2,this.y+(this.w-10)/2,10,10,"green",1,0.5,50));
        w.push(new Bullet(this.x+(this.w-10)/2,this.y+(this.w-10)/2,10,10,"green",-1,0.5,50));
    }
    else if(this.hp<3000)
    {
        let dx=(this.pl.x+this.pl.w/2-5)-(this.x+this.w/2-5);
        let dy=(this.pl.y+this.pl.h/2-5)-(this.y+this.h/2-5);
        w.push(new Bullet(this.x+105,this.y+(this.w-15)/2,10,10,"green",0.75*Math.cos(Math.atan2(dy,dx)),
        0.75*Math.sin(Math.atan2(dy,dx)),50));
        w.push(new Bullet(this.x+105,this.y+(this.w-15)/2,10,10,"green",0.75*Math.cos(Math.atan2(dy,dx)-1),
        0.75*Math.sin(Math.atan2(dy,dx)-1),50));
        w.push(new Bullet(this.x+105,this.y+(this.w-15)/2,10,10,"green",0.75*Math.cos(Math.atan2(dy,dx)+1),
        0.75*Math.sin(Math.atan2(dy,dx)+1),50));
        w.push(new Bullet(this.x+105,this.y+(this.w-15)/2,10,10,"green",0.75*Math.cos(Math.atan2(dy,dx)+2),
        0.75*Math.sin(Math.atan2(dy,dx)+2),50));
        w.push(new Bullet(this.x+105,this.y+(this.w-15)/2,10,10,"green",0.75*Math.cos(Math.atan2(dy,dx)-2),
        0.75*Math.sin(Math.atan2(dy,dx)-2),50));
    }
    else
    {
        let dx=(this.pl.x+this.pl.w/2-5)-(this.x+this.w/2-5);
        let dy=(this.pl.y+this.pl.h/2-5)-(this.y+this.h/2-5);
        w.push(new Bullet(this.x+105,this.y+(this.w-15)/2,10,10,"green",0.5*Math.cos(Math.atan2(dy,dx)),
        0.5*Math.sin(Math.atan2(dy,dx)),50));
        w.push(new Cosinus(this.x+(this.w-10)/2,this.y+(this.w-10)/2+40,10,10,"green",(this.vx>0?1:-1),0,50));
        w.push(new Cosinus(this.x+(this.w-10)/2,this.y+(this.w-10)/2-40,10,10,"green",(this.vx>0?1:-1),0,50));
    }}
    }
    draw=function(dx,dy)
{
    ctx.fillStyle=this.c;
    ctx.fillRect(this.x-dx,this.y-dy,this.w,this.h);
    ctx.fillStyle='black';
    ctx.fillRect(836,10,200,10);
    ctx.fillStyle='green';
    ctx.fillRect(836,10,200*(this.hp/this.mhp),10);
}
whendown=function(){if(this.hp>4500&&this.hp<7500)this.g='U';}
whenup=function(){this.g='D';}
move=function()
{
    this.x+=this.vx;this.y+=this.vy;if(this.g=='D')this.vy+=0.05;else this.vy-=0.05;
}
}