function aftergame(ctx,lv)
{
    if(lv==34)
    {
    ctx.font="40px verdana";
    ctx.fillStyle="black";
    ctx.fillText('Congratulations! You have defeated Cotangens. The whole game is finished successfully.',20,40);
    }
}