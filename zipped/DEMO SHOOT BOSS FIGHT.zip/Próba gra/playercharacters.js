let pltype;

const playertypes=
[
    'Normal',
    'Downup',
    'Spark',
    'Climb',
    'Chtery',
    'Wind',
]

function choose_character(ctx)
{
    ctx.font="40px verdana";
    ctx.fillStyle="black";
    ctx.fillText("Choose the character by pressing a key with number:",40,120);

    for(i in playertypes)
    ctx.fillText(i+' '+playertypes[i],40,160+i*40);
}