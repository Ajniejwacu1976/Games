function beforegame(ctx)
{
    ctx.font="40px verdana";
    ctx.fillStyle="black";
    ctx.fillText("Press SHIFT to start the game.",0,40);
    ctx.fillText("Greetings to Krzysztof Hrynkiewicz, past member of Aidem Media.",0,908);
}

function hello()
{
    ctx.font="40px verdana";
ctx.fillStyle="black";
ctx.fillText("Click to move to the game.",0,40);
ctx.fillText("Copyright © 2023-24 by Ajniejwacu1976. All rights reserved.",0,600);
const logo=document.getElementById("logo");
ctx.drawImage(logo,0,0,714,321,540,0,714,321);
}

let allem=0,killed=0,appeareden=0;