let cx,cy,pm=false;

document.getElementsByTagName('canvas')[0].onmousedown=function()
{
pm=true;
}

document.getElementsByTagName('canvas')[0].onmouseup=function()
{
pm=false;
}

document.getElementsByTagName('canvas')[0].onmousemove=function()
{
cx=event.offsetX;cy=event.offsetY;
}

function inrect(x,y,w,h,cx,cy)
{
if(cx>=x&&cx<=x+w&&cy>=y&&cy<=y+h)return true;return false;
}

function pythagoras(a,b)
{
return Math.sqrt(a*a+b*b);
}

function inwheel(x,y,r,cx,cy)
{
if(pythagoras(cx-x,cy-y)<=r)return true;return false;
}

function drawwheel(ctx,x,y,r)
{
ctx.beginPath();
ctx.arc(x,y,r,0,8);
ctx.fill();
ctx.closePath();
}

function rads(degs)
{
return degs*Math.PI/180;
}

function arc(ctx,x,y,r,b,e)
{
ctx.beginPath();
ctx.arc(x,y,r,rads(b),rads(e));
ctx.stroke();
ctx.closePath();
}

function line(ctx,bx,by,ex,ey)
{
ctx.beginPath();
ctx.moveTo(bx,by);
ctx.lineTo(ex,ey);
ctx.stroke();
ctx.closePath();
}

function rand_cc(b,e)
{
return Math.floor(Math.random()*(e-b+1))+b;
}

function shuffle(a)
{
for(let i=0;i<1000000;i++)
{
let x=rand_cc(0,a.length-1);
let y=rand_cc(0,a.length-1);
let t=a[x];
a[x]=a[y];
a[y]=t;
}
}
