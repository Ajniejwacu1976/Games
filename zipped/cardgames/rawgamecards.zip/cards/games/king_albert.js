class KingAlbert extends Game
{
constructor()
{
super();
let sup=new Supply();sup.load();
this.mode=0;
this.a=[];
for(let i=0;i<9;i++)
{
this.a.push([new CardForm(new Card(0),10+50*i,80,40,60,4)]);
}


let ccol=0;
let gc;

for(let i=0;i<9;i++)
{
for(let j=i;j<9;j++)
{
gc=sup.get();
this.a[i].push(new CardForm(gc,10+50*i,80,40,60,4));
this.a[i][this.a[i].length-1].hide();
}
}




this.b=[];
for(let i=0;i<4;i++)
{
this.b.push([new CardForm(new Card(0),60+i*100,10,40,60,4)]);
}

let poses=[[460,10],[510,45],[460,80],[510,115],[460,150],[510,185],[460,220]];

this.c=[];
for(let i=0;i<7;i++)
{
this.c.push([new CardForm(new Card(0),poses[i][0],poses[i][1],40,60,4)]);
this.c[i].push(new CardForm(sup.get(),60,10,40,60,4));
}

/*new CardForm(new Card(0),10,10,40,60,4)];this.a.push(new CardForm(sup.get(),10,10,40,60,4));
this.b=[new CardForm(new Card(0),60,10,40,60,4)];this.b.push(new CardForm(sup.get(),60,10,40,60,4));*/

this.waste=[];

let getfs;

while((getfs=sup.get()))
{
if(getfs.cf==0)break;
this.waste.push(Object.assign({},new CardForm(getfs,10,10,40,60,4)));
this.waste[this.waste.length-1].hide();
}

this.got=[];
this.gx=0;this.gy=0;this.lms=false;

this.colors='';
this.highest=1;

}

ctc=function(c)
{
switch(((c.card.cf)&48))
{
case 0:return 'S';
case 16:return 'H';
case 32:return 'C';
case 48:return 'D';
default: console.error('Something went wrong. Suit was not chosen.');
}
}

//The most imfortant function
manage=function(x,y,s)
{

let rb=false;
for(let i=0;i<1;i++)
if(s&&this.lms==false)
{

//////
//BEGIN: GETCARDS

for(let k=0;k<this.a.length;k++)
{rb=false;
for(let j=1;j<this.a[k].length;j++)
if(this.a[k][j].onit(x,y)&&this.got.length==0)
{
if(j+1<this.a[k].length)
{
if(this.a[k][j+1].onit(x,y))continue;
}
this.mode=k;
this.got.push(Object.assign({},this.a[k][j]))
if(j+1<this.a[k].length)
while(this.a[k][j].together(this.a[k][j+1]))
{
this.got.push(Object.assign({},this.a[k][j+1]));
this.a[k].splice(j,1);
//console.log(this.got);
if(j+1==this.a[k].length)break;
}
this.gx=x;this.gy=y;this.a[k].pop();rb=true;
}
else if(this.got.length!=0&&this.mode==k)
{
this.a[k].push(Object.assign({},this.got[0]));
this.got.splice(0,this.got.length);break;
}
if(rb)break;
}



for(let k=0;k<this.c.length;k++)
{rb=false;
for(let j=1;j<this.c[k].length;j++)
if(this.c[k][j].onit(x,y)&&this.got.length==0)
{
if(j+1<this.c[k].length)
{
if(this.c[k][j+1].onit(x,y))continue;
}
this.mode=k+200;
this.got.push(Object.assign({},this.c[k][j]))
if(j+1<this.c[k].length)
while(this.c[k][j].together(this.c[k][j+1]))
{
this.got.push(Object.assign({},this.c[k][j+1]));
this.c[k].splice(j,1);
//console.log(this.got);
if(j+1==this.c[k].length)break;
}
this.gx=x;this.gy=y;this.c[k].pop();rb=true;
}
else if(this.got.length!=0&&this.mode==k+200)
{
this.c[k].push(Object.assign({},this.got[0]));
this.got.splice(0,this.got.length);break;
}
if(rb)break;
}







//END: GETCARDS
//////




//////

}

for(let i=0;i<1;i++)
{
if(this.lms&&!s)//MOUSEUP
{
if(this.got.length==0)break;

/******/

//BEGIN: adding cards to a column
for(let k=0;k<this.a.length;k++)
if(this.a[k].length-1>=0)
if(this.a[k][this.a[k].length-1].onit(x,y))
{

if(this.a[k].length>1)
{
if(this.got[Number(i)].getcolor()==this.a[k][this.a[k].length-1].getcolor())break;
if(this.got[Number(i)].getvalue()-this.a[k][this.a[k].length-1].getvalue()!=-1)break;
}



for(let i in this.got)
{
if(this.colors.search(this.ctc(Object.assign({},this.got[0])))==-1)this.colors+=this.ctc(Object.assign({},this.got[0]));
this.a[k].push(Object.assign({},this.got[i]));
}
this.got=[];break;
}

for(let k=0;k<this.b.length;k++)
if(this.b.length-1>=0)
{
if(this.b[k][this.b[k].length-1].onit(x,y))
{
if(this.got.length>1)break;
if(this.mode>=100&&this.mode<200)break;
if(this.b[k].length==1&&this.got[0].getvalue()!=1)break;
if(this.b[k].length>1&&this.got[0].getvalue()-this.b[k][this.b[k].length-1].getvalue()!=1)break;
if(this.b[k][this.b[k].length-1].getsuit()!=this.got[0].getsuit()&&this.b[k].length>1)break;

for(let i in this.got)
{
this.b[k].push(Object.assign({},this.got[i]));
}
this.got=[];break;
}
}

for(let k=0;k<this.c.length;k++)
if(this.c.length-1>=0)
{
if(this.c[k][this.c[k].length-1].onit(x,y))
{
if(((this.c[k][this.c[k].length-1].card.cf&15)-(this.got[0].card.cf&15)!=-1)&&this.c[k].length!=1)break;
if(this.c[k].length==1&&(this.got[0].card.cf&15)!=1)break;
if(this.c[k].length!=1&&(this.got[0].card.cf&48)!=(this.c[k][this.c[k].length-1].card.cf&48))break;
for(let i in this.got)
{
this.c[k].push(Object.assign({},this.got[i]));
}
this.got=[];break;
}
}
//END: adding cards to a column


/*******/

//END: giving back cards
for(let k=0;k<this.a.length;k++)
if(this.mode==k&&this.got.length!=0)
{
for(let j in this.got)
this.a[k].push(Object.assign({},this.got[Number(j)]));
this.got.splice(0,this.got.length);break;
}

for(let k=0;k<this.b.length;k++)
if(this.mode==k+100&&this.got.length!=0)
{
for(let j in this.got)
this.b[k].push(Object.assign({},this.got[Number(j)]));
this.got.splice(0,this.got.length);break;
}

for(let k=0;k<this.c.length;k++)
if(this.mode==k+200&&this.got.length!=0)
{
for(let j in this.got)
this.c[k].push(Object.assign({},this.got[Number(j)]));
this.got.splice(0,this.got.length);break;
}
//END: giving back cards


}

/********/


/*
if(this.got.length==0&&this.waste.length>0)
{

////

for(let k=0;k<this.a.length;k++)
if(this.a[k].length==1)
{
this.a[k].push(Object.assign({},new CardForm(this.waste[0],this.a[k][0].x,this.a[k][0].y,this.a[k][0].w,this.a[k][0].h,this.a[k][0].r)));
this.waste.shift();
}


////

}*/
}//END: MOUSEUP

if(this.got.length==0)
for(let i in this.a)
{
this.a[Number(i)][this.a[i].length-1].reveal();
}


let gotok=true;//Are taken cards OK?


for(let i in this.got)
{
if(this.got[Number(i)].ishidden()){gotok=false;break;}
if(Number(i)==0)continue;

if(this.got[Number(i)].getcolor()==this.got[Number(i-1)].getcolor()){gotok=false;break;}
if(this.got[Number(i)].getvalue()-this.got[Number(i-1)].getvalue()!=-1){gotok=false;break;}
}


if(!gotok)
{
for(let k=0;k<this.a.length;k++)
if(this.mode==k&&this.got.length!=0)
{
for(let j in this.got)
this.a[k].push(Object.assign({},this.got[Number(j)]));
this.got.splice(0,this.got.length);break;
}
for(let k=0;k<this.b.length;k++)
if(this.mode==k+100&&this.got.length!=0)
{
for(let j in this.got)
this.b[k].push(Object.assign({},this.got[Number(j)]));
this.got.splice(0,this.got.length);break;
}
}


/******/

//Correction
for(let j in this.a)
for(let i in this.a[j])
{
if(i==0)continue;
this.a[j][i].y=this.a[j][Number(i)-1].y+(i==1?0:20);
this.a[j][i].x=this.a[j][Number(i)-1].x;
}

for(let i=0;i<this.a.length;i++)
{
if(i==0){this.hightest=this.a[i].length;break;}
if(this.a[i].length>this.hightest)this.hightest=this.a[i].length;
}

for(let j in this.b)
for(let i in this.b[j])
{
if(i==0)continue;
this.b[j][i].y=this.b[j][Number(i)-1].y;
this.b[j][i].x=this.b[j][Number(i)-1].x;
}

for(let j in this.c)
for(let i in this.c[j])
{
if(i==0)continue;
this.c[j][i].y=this.c[j][Number(i)-1].y;
this.c[j][i].x=this.c[j][Number(i)-1].x;
}

for(let i in this.waste)
{
if(i==0)continue;
this.waste[i].y=this.waste[Number(i)-1].y;
this.waste[i].x=this.waste[Number(i)-1].x;
}


//BEGIN: DRAW
for(let k=0;k<this.a.length;k++)
for(let i in this.a[k])
{
this.a[Number(k)][Number(i)].draw();
}

for(let k=0;k<this.b.length;k++)
for(let i in this.b[k])
{
this.b[Number(k)][Number(i)].draw();
}

for(let k=0;k<this.c.length;k++)
for(let i in this.c[k])
{
this.c[Number(k)][Number(i)].draw();
}


//END: DRAW

for(let i in this.got)
{
this.got[i].draw(x-this.gx,y-this.gy);
}

this.lms=s;
};
//the most important function:end



won=function()
{
for(let i=0;i<this.b.length;i++)
{
if(this.b[i].length>1)return false;
}
for(let i=0;i<this.a.length;i++)
{
if(this.a[i].length>1)return false;
}
};
};
