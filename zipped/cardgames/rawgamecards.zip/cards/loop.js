let game=new Game();

function go()
{
backgr('#008000');
game.manage(cx,cy,pm);

}

window.setInterval(go,1);
