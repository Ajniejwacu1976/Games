const
S_S=0,
S_H=16,
S_C=32,
S_D=48,
SC_J=15,
HOLDER=14,
NOTHING=0,
HIDDEN=64;

class Card
{
constructor(value,color,hidden)
{
this.cf=value;
if(value>13||value<1)return;
this.cf|=color;
this.cf|=hidden;
}
show=function()
{
let consolelog='';
switch(this.cf&15)
{
case 0: console.log('  ');return;
case 14: console.log('[]');return;
case 15: console.log('@@');return;
}
switch(this.cf&15)
{
case 1:consolelog='A';break;
case 10:consolelog='%';break;
case 11:consolelog='J';break;
case 12:consolelog='Q';break;
case 13:consolelog='K';break;
}
switch(this.cf&48)
{
case S_S:consolelog+=('S');break;
case S_H:consolelog+=('H');break;
case S_C:consolelog+=('C');break;
case S_D:consolelog+=('D');break;
}
console.log(consolelog);
}
};
