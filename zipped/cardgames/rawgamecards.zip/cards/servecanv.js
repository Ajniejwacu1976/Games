const canvas=document.getElementById("canvas");
const ctx=canvas.getContext("2d");

function backgr(c)
{
ctx.fillStyle=c;
ctx.fillRect(0,0,canvas.width,canvas.height);
}
