function getsuit(i)
{
switch(i)
{
case 0:return S_S;
case 1:return S_H;
case 2:return S_C;
case 3:return S_D;
}
}

class Supply
{
constructor()
{
this.sup=[];
}
load=function()
{
if(this.sup.length!=0)return;
for(let i=0;i<52;i++)
{
this.sup.push(new Card(i%13+1,getsuit(Math.floor(i/13)),0));
}
shuffle(this.sup);
}


get=function()
{
if(this.sup.length==0)return new Card(0);
let taken=Object.assign({},this.sup[0]);
this.sup.shift();
return taken;
}

};
