let game=new Game();

function go()
{
if(game.won())
backgr('#000088','#00ffff');
else
backgr('#008000','#00ff00');
game.manage(cx,cy,pm);

}

window.setInterval(go,1);
