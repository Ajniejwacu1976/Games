class CardForm
{
constructor(card,x,y,w,h,r)
{
this.card=card;
this.x=x;this.y=y;this.w=w;this.h=h;this.r=r;
}
onit=function(ecx,ecy)
{
if(inrect(this.x+this.r,this.y,this.w-this.r,this.h,ecx,ecy))return true;
if(inrect(this.x,this.y+this.r,this.w,this.h-this.r,ecx,ecy))return true;

if(inwheel(this.x+this.r,this.y+this.r,this.r,ecx,ecy))return true;
if(inwheel(this.x+this.w-this.r,this.y+this.r,this.r,ecx,ecy))return true;
if(inwheel(this.x+this.w-this.r,this.y+this.h-this.r,this.r,ecx,ecy))return true;
if(inwheel(this.x+this.r,this.y+this.h-this.r,this.r,ecx,ecy))return true;

return false;

}

draw=function(rx=0,ry=0)
{
ctx.strokeStyle='black';
if(this.card.cf==0)
ctx.fillStyle='transparent';

else if((this.card.cf&64)==64)
ctx.fillStyle='crimson';
else
ctx.fillStyle='white';
ctx.fillRect(this.x+this.r+rx,this.y+ry,this.w-this.r*2,this.h);
ctx.fillRect(this.x+rx,this.y+this.r+ry,this.w,this.h-this.r*2);
drawwheel(ctx,this.x+this.r+rx,this.y+this.r+ry,this.r);
drawwheel(ctx,this.x+this.w-this.r+rx,this.y+this.r+ry,this.r);
drawwheel(ctx,this.x+this.w-this.r+rx,this.y+this.h-this.r+ry,this.r);
drawwheel(ctx,this.x+this.r+rx,this.y+this.h-this.r+ry,this.r);

arc(ctx,this.x+this.r+rx,this.y+this.r+ry,this.r,180,270);
arc(ctx,this.x+this.w-this.r+rx,this.y+this.r+ry,this.r,270,360);
arc(ctx,this.x+this.w-this.r+rx,this.y+this.h-this.r+ry,this.r,0,90);
arc(ctx,this.x+this.r+rx,this.y+this.h-this.r+ry,this.r,90,180);
line(ctx,this.x+this.r+rx,this.y+ry,this.x+this.w-this.r+rx,this.y+ry);
line(ctx,this.x+this.r+rx,this.y+this.h+ry,this.x+this.w-this.r+rx,this.y+this.h+ry);
line(ctx,this.x+rx,this.y+this.r+ry,this.x+rx,this.y+this.h-this.r+ry);
line(ctx,this.x+this.w+rx,this.y+this.r+ry,this.x+this.w+rx,this.y+this.h-this.r+ry);


if(this.card.cf==0||(this.card.cf&64)==64)return;
if((this.card.cf&16)==16)
ctx.fillStyle='red';
else
ctx.fillStyle='black';

ctx.font='16px courier';

switch(this.card.cf&15)
{
case 1:ctx.fillText('A',this.x+rx,this.y+ry+16);break;
case 10:ctx.fillText('%',this.x+rx,this.y+ry+16);break;
case 11:ctx.fillText('J',this.x+rx,this.y+ry+16);break;
case 12:ctx.fillText('Q',this.x+rx,this.y+ry+16);break;
case 13:ctx.fillText('K',this.x+rx,this.y+ry+16);break;
default:ctx.fillText(this.card.cf&15,this.x+rx,this.y+ry+16);break;
}

switch(this.card.cf&48)
{
case S_S:ctx.fillText('S',this.x+rx+16,this.y+ry+16);break;
case S_H:ctx.fillText('H',this.x+rx+16,this.y+ry+16);break;
case S_C:ctx.fillText('C',this.x+rx+16,this.y+ry+16);break;
case S_D:ctx.fillText('D',this.x+rx+16,this.y+ry+16);break;
}

}

deletecard=function()
{
this.card=new Card(0);
}

fits=function(cf)
{
if(this.x==cf.x&&this.y==cf.y)return true;return false;
}

hide=function()
{
this.card.cf|=64;
}

reveal=function()
{
this.card.cf&=191;
}

together=function(a)
{
if(this.x+this.w>=a.x&&this.x<=a.x+a.w)return true;return false;
}

getvalue=function()
{
return (this.card.cf&15);
}

getsuit=function()
{
return (this.card.cf&48);
}

getcolor=function()
{
return (this.card.cf&16);
}

ishidden=function()
{
if((this.card.cf&64)==64)return true;return false;
}

}
