const

baselabels=[
"Athena",
"Batcher's dozen",
"Brawl stars",
"Bucharest",
"Control",
"Cute Finnish Woman",
"Diamond mine",
"Eagle Wing",
"Eight off",
"Forty Thieves",
"Freecell",
"Isabel",
"Jamestown",
"King Albert",
"Klondike",
"Lady Jane",
"Magyar",
"Monte Carlo",
"Neighbour",
"Osmosis",
"Paulina",
"Pileon",
"Scorpion",
"Union Square",
"Whitehead",
"Will o' the Wisp",
"Yield",
"Yukon",
],

base_choose="Choose a game";

function sortselectbyvalue()
{
for(let i=0;i<select.length-1;i++)
{
for(let j=i;j<select.length-1;j++)
{
if(select[i].value>select[j].value)
{
let t=select[i].value;
select[i].value=select[j].value;
select[j].value=t;
}
}
}
}

function changelang(labs,choose)
{
for(let i=0;i<select.length-1;i++)
{
select[i].innerHTML=labs[i];
}
select[select.length-1].innerHTML='-- '+choose+' --';
}

function cl_type(a,b){return a>b}
//>
function sort_back(type=cl_type)
{
for(let i=0;i<select.length-1;i++)
{
for(let j=i;j<select.length-1;j++)
{
if(type(select[i].innerHTML,select[j].innerHTML))
{
let t=select[i].value;
let tt=select[i].innerHTML;
select[i].value=select[j].value;
select[i].innerHTML=select[j].innerHTML;
select[j].value=t;
select[j].innerHTML=tt;
}
}
}
}

function real_changelang(type=function(a,b){return a>b},labs=baselabels,choose=base_choose)
{
let temp=select.value;
sortselectbyvalue();
changelang(labs,choose);
sort_back(type);
select.value=temp;
}

function putchar(str,c,i)
{
return str.substr(0,i)+c+str.substr(i+1);
}
