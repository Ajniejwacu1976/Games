const l_polish=

[
"Atena",
"Piekarski tuzin",
"Maćki",
"Bukareszt",
"Sterowaniec",
"Urocza Finka",
"Kopalnia diamentów",
"Skrzydło orła",
"Ósemka odpada",
"Czterdziestu rozbójników",
"Freecell",
"Isabel",
"Jamestown",
"Król Albert",
"Klondike",
"Lady Jane",
"Madziar",
"Monte Carlo",
"Sąsiad",
"Osmoza",
"Paulina",
"Wyolbrzymienie",
"Skorpion",
"Plac Unii",
"Starzec",
"Złudne nadzieje",
"Zysk",
"Jukon",
],
l_pl_choose="Wybierz grę";

function type_pl(a,b)
{
const all='aąbcćdeęfghijklłmnńoópqrsśtuvwxyzźż';

if(a.length>b.length)
{
for(let i=0;i<b.length;i++)
{
if(all.search(a.charAt(i).toLowerCase())<all.search(b.charAt(i).toLowerCase()))return false;
if(all.search(a.charAt(i).toLowerCase())>all.search(b.charAt(i).toLowerCase()))return true;
}
}
else
{
for(let i=0;i<a.length;i++)
{
if(all.search(a.charAt(i).toLowerCase())<all.search(b.charAt(i).toLowerCase()))return false;
if(all.search(a.charAt(i).toLowerCase())>all.search(b.charAt(i).toLowerCase()))return true;
}
}

if(a.length>b.length)return false;
return true;
}
