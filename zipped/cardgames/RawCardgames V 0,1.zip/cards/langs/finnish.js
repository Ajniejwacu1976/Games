const l_finnish=

[
"Atena",
"Piekarski tuzin",
"Maćki",
"Bukareszt",
"Sterowaniec",
"Urocza Finka",
"Kopalnia diamentów",
"Skrzydło orła",
"Ósemka odpada",
"Czterdziestu rozbójników",
"Freecell",
"Isabel",
"Jamestown",
"Król Albert",
"Klondike",
"Lady Jane",
"Madziar",
"Monte Carlo",
"Sąsiad",
"Osmoza",
"Paulina",
"Wyolbrzymienie",
"Skorpion",
"Plac Unii",
"Starzec",
"Złudne nadzieje",
"Zysk",
"Jukon",
],
l_fi_choose="Wybierz grę";

function type_fi(a,b)
{


for(let i=0;i<a.length;i++)
{
if(a.charAt(i)=='ä')
a=putchar(a,'a',i);
if(a.charAt(i)=='ö')
a=putchar(a,'o',i);
}
for(let i=0;i<b.length;i++)
{
if(b.charAt(i)=='ä')
a=putchar(b,'a',i);
if(b.charAt(i)=='ö')
a=putchar(b,'o',i);
}

if(a<b)return false;
if(a>b)return true

if(a.length>b.length)return false;
return true;
}
