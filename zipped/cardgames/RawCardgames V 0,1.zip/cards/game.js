class Game
{
constructor()
{
};
manage=function(x,y,s)
{
};
won=function()
{
};
};

let size=2;
