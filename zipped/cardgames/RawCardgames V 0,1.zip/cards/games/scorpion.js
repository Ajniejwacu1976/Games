class Scorpion extends Game
{
constructor()
{
super();
let sup=new Supply();sup.load();
this.mode=0;
this.a=[];
for(let i=0;i<7;i++)
{
this.a.push([new CardForm(new Card(0),10+50*i,10,40,60,4)]);
}

let ccol=0;
let gc;

{

/*
this.a[ccol%(this.a.length)].push(gc);*/


for(let i=1;i<8;i++)
for(let j=0;j<4;j++)
{
gc=new CardForm(sup.get(),0,0,40,60,4);
if(i<4)
gc.hide();
this.a[j].push(gc);
}

for(let i=4;i<7;i++)
{
for(let j=0;j<7;j++)
{
gc=new CardForm(sup.get(),0,0,40,60,4);
this.a[i].push(gc);
}
}


}




/*new CardForm(new Card(0),10,10,40,60,4)];this.a.push(new CardForm(sup.get(),10,10,40,60,4));
this.b=[new CardForm(new Card(0),60,10,40,60,4)];this.b.push(new CardForm(sup.get(),60,10,40,60,4));*/

this.waste=[];

let getfs;

while((getfs=sup.get()))
{
if(getfs.cf==0)break;
this.waste.push(Object.assign({},new CardForm(getfs,360,10,40,60,4)));
this.waste[this.waste.length-1].hide();
}

this.got=[];
this.gx=0;this.gy=0;this.lms=false;



}

//The most imfortant function
manage=function(x,y,s)
{

let rb=false;
for(let i=0;i<1;i++)
if(s&&this.lms==false)
{

//////
//BEGIN: GETCARDS

for(let k=0;k<this.a.length;k++)
{rb=false;
for(let j=1;j<this.a[k].length;j++)
if(this.a[k][j].onit(x,y)&&this.got.length==0)
{
if(j+1<this.a[k].length)
{
if(this.a[k][j+1].onit(x,y))continue;
}
this.mode=k;
this.got.push(Object.assign({},this.a[k][j]))
if(j+1<this.a[k].length)
while(this.a[k][j].together(this.a[k][j+1]))
{
this.got.push(Object.assign({},this.a[k][j+1]));
this.a[k].splice(j,1);
//console.log(this.got);
if(j+1==this.a[k].length)break;
}
this.gx=x;this.gy=y;this.a[k].pop();rb=true;
}
else if(this.got.length!=0&&this.mode==k)
{
this.a[k].push(Object.assign({},this.got[0]));
this.got.splice(0,this.got.length);break;
}
if(rb)break;
}

if(this.waste.length>0)
if(this.waste[0].onit(x,y))
{
for(let i=0;i<3;i++)
{
this.a[i].push(this.waste[0]);
this.waste.shift();
}
}

//END: GETCARDS
//////




//////

}

for(let i=0;i<1;i++)
{
if(this.lms&&!s)//MOUSEUP
{
if(this.got.length==0)break;

/******/

//BEGIN: adding cards to a column
for(let k=0;k<this.a.length;k++)
if(this.a[k].length-1>=0)
if(this.a[k][this.a[k].length-1].onit(x,y))
{
if(((this.a[k][this.a[k].length-1].card.cf&15)-(this.got[0].card.cf&15)!=1)&&this.a[k].length!=1)break;
if(((this.a[k][this.a[k].length-1].getsuit())!=(this.got[0].getsuit()))&&this.a[k].length!=1)break;
if(this.a[k].length==1&&((this.got[0].card.cf&15)!=13))break;
for(let i in this.got)
{
this.a[k].push(Object.assign({},this.got[i]));
}
this.got=[];break;
}



//END: adding cards to a column


/*******/

//END: giving back cards
for(let k=0;k<this.a.length;k++)
if(this.mode==k&&this.got.length!=0)
{
for(let j in this.got)
this.a[k].push(Object.assign({},this.got[Number(j)]));
this.got.splice(0,this.got.length);break;
}


//END: giving back cards


}

/********/

if(this.got.length==0&&this.waste.length>0)
{

////




////



}

}//END: MOUSEUP

if(this.got.length==0)
for(let i in this.a)
{
this.a[Number(i)][this.a[i].length-1].reveal();
}


let gotok=true;//Are taken cards OK?

for(let i in this.got)
{
if((this.got[Number(i)].card.cf&64)==64)gotok=false;break;
}


if(this.got.length>this.tocol+1)gotok=false;

if(!gotok)
for(let k=0;k<this.a.length;k++)
if(this.mode==k&&this.got.length!=0)
{
for(let j in this.got)
this.a[k].push(Object.assign({},this.got[Number(j)]));
this.got.splice(0,this.got.length);break;
}



/******/

//Correction
for(let j in this.a)
for(let i in this.a[j])
{
if(i==0)continue;
this.a[j][i].y=this.a[j][Number(i)-1].y+(i==1?0:20);
this.a[j][i].x=this.a[j][Number(i)-1].x;
}






//BEGIN: DRAW
for(let k=0;k<this.a.length;k++)
for(let i in this.a[k])
{
this.a[Number(k)][Number(i)].draw();
}

if(this.waste.length>0)
this.waste[0].draw();


//END: DRAW

for(let i in this.got)
{
this.got[i].draw(x-this.gx,y-this.gy);
}

this.lms=s;
};
//the most important function:end



won=function()
{
for(let i=0;i<this.a.length;i++)
{
if(this.a[i].length==1)continue;
if(this.a[i].length!=14)return false;
for(let j=2;j<this.a[i].length;j++)
{
if(this.a[i][j].getsuit()!=this.a[i][j-1].getsuit()||this.a[i][j-1].getvalue()-this.a[i][j].getvalue()!=1)return false;
}
}
return true;
};
};
