class MonteCarlo extends Game
{
constructor()
{
super();
let sup=new Supply();sup.load();
this.mode=0;

size=4;




this.a=[];

for(let i=0;i<5;i++)
{
this.a.push([[new UCardForm(new Card(0),20+size*20,15+(i*30*size)+i*10,size)]]);
for(let j=0;j<4;j++)
{
this.a[i].push([new UCardForm(new Card(0),20+(j+2)*(size*20)+(j+1)*10,15+(i*30*size)+i*10,size)]);
this.a[i][j].push(new UCardForm(sup.get(),20+size*20,10,size));
}
}

for(let i=0;i<5;i++)
{
this.a[i][4].push(new UCardForm(sup.get(),20+size*20,10,size));
}

let ccol=0;
let gc;











/*new CardForm(new Card(0),10,10,40,60,4)];this.a.push(new CardForm(sup.get(),10,10,40,60,4));
this.b=[new CardForm(new Card(0),60,10,40,60,4)];this.b.push(new CardForm(sup.get(),60,10,40,60,4));*/

this.waste=[];

let getfs;

while((getfs=sup.get()))
{
if(getfs.cf==0)break;
this.waste.push(Object.assign({},new UCardForm(getfs,10,10,size)));
this.waste[this.waste.length-1].hide();
}

this.waste.push(new UCardForm(new Card(0),10,10,size));

this.got=[];
this.gx=0;this.gy=0;this.lms=false;



}

testisok=function(beg,end)
{
let ones=Math.abs(beg%10)-Math.abs(end%10);
if(ones!=1&&ones!=0&&ones!=-1)return false;
ones=Math.abs(Math.floor(beg/100))-Math.abs(Math.floor(end/100));
if(ones!=1&&ones!=0&&ones!=-1)return false;
return true;
}

//The most imfortant function
manage=function(x,y,s)
{

let rb=false;
for(let i=0;i<1;i++)
if(s&&this.lms==false)
{
//////
//BEGIN: GETCARDS

for(let k=0;k<this.a.length;k++)
for(let l=0;l<this.a[k].length;l++)
{rb=false;
for(let j=1;j<this.a[k][l].length;j++)
if(this.a[k][l][j].onit(x,y)&&this.got.length==0)
{
if(j+1<this.a[k][l].length)
{
if(this.a[k][l][j+1].onit(x,y))continue;
}
this.mode=k+l*100;
this.got.push(Object.assign({},this.a[k][l][j]))
if(j+1<this.a[k][l].length)
while(this.a[k][l][j].together(this.a[k][l][j+1]))
{
this.got.push(Object.assign({},this.a[k][l][j+1]));
this.a[k][l].splice(j,1);
//console.log(this.got);
if(j+1==this.a[k][l].length)break;
}
this.gx=x;this.gy=y;this.a[k][l].pop();rb=true;
}
else if(this.got.length!=0&&this.mode==k+l*100)
{
this.a[k][l].push(Object.assign({},this.got[0]));
this.got.splice(0,this.got.length);break;
}
if(rb)break;
}



if(this.waste[0].onit(x,y)&&this.got.length==0)
{
let bbr=false;
if(this.got.length==0)
for(let k=1;k<25;k++)
{
if(this.a[Math.floor((k-1)/5)][(k-1)%5].length==1)
for(let l=k;l<25;l++)
{
if(this.a[Math.floor(l/5)][l%5].length==2)
{
this.a[Math.floor((k-1)/5)][(k-1)%5].push(Object.assign({},this.a[Math.floor(l/5)][l%5][1]));
this.a[Math.floor(l/5)][l%5].pop();break;
}
if(l==24)bbr=true;
}
if(bbr)break;
}

if(this.got.length==0&&this.waste.length>1)
{
for(let i in this.a)
for(let j in this.a[i])
{
if(this.a[Number(i)][Number(j)].length==1)
{
this.a[Number(i)][Number(j)].push(Object.assign({},this.waste[0]));
this.waste.shift();
if(this.waste.length==1)break;
}
}


}

}



//END: GETCARDS
//////




//////

}

for(let i=0;i<1;i++)
{
if(this.lms&&!s)//MOUSEUP
{
if(this.got.length==0)break;

/******/

//BEGIN: adding cards to a column
for(let k=0;k<this.a.length;k++)
for(let l=0;l<this.a[k].length;l++)
if(this.a[k][l].length-1>=0)
if(this.a[k][l][this.a[k][l].length-1].onit(x,y))
{



if(this.a[k][l].length>1)
{

if(this.got[0].getvalue()!=this.a[k][l][this.a[k][l].length-1].getvalue())break;
}
else break;

if(this.testisok(this.mode,k+l*100)==false)break;

this.a[k][l].pop();



this.got=[];break;
}




//END: adding cards to a column


/*******/

//END: giving back cards

for(let k=0;k<this.a.length;k++)
for(let l=0;l<this.a[k].length;l++)
if(this.mode==k+l*100&&this.got.length!=0)
{
for(let j in this.got)
this.a[k][l].push(Object.assign({},this.got[Number(j)]));
this.got.splice(0,this.got.length);break;
}

//END: giving back cards


}

/********/


/*
if(this.got.length==0&&this.waste.length>0)
{

////

for(let k=0;k<this.a.length;k++)
if(this.a[k].length==1)
{
this.a[k].push(Object.assign({},new CardForm(this.waste[0],this.a[k][0].x,this.a[k][0].y,this.a[k][0].w,this.a[k][0].h,this.a[k][0].r)));
this.waste.shift();
}


////

}*/
}//END: MOUSEUP

if(this.got.length==0)
for(let i in this.a)
for(let j in this.a[i])
{
this.a[Number(i)][Number(j)][this.a[i][j].length-1].reveal();

}


let gotok=true;//Are taken cards OK?


for(let i in this.got)
{
if(this.got[Number(i)].ishidden()){gotok=false;break;}
if(Number(i)==0)continue;

if(this.got[Number(i)].getvalue()-this.got[Number(i-1)].getvalue()!=-1){gotok=false;break;}
}


if(!gotok)
{
for(let k=0;k<this.a.length;k++)
if(this.mode==k&&this.got.length!=0)
{
for(let j in this.got)
this.a[k].push(Object.assign({},this.got[Number(j)]));
this.got.splice(0,this.got.length);break;
}

}


/******/

//Correction
for(let j in this.a)
for(let i in this.a[j])
for(let k in this.a[j][i])
{
if(k==0)continue;
this.a[j][i][Number(k)].y=this.a[j][i][Number(k)-1].y;
this.a[j][i][Number(k)].x=this.a[j][i][Number(k)-1].x;
}






for(let i in this.waste)
{
if(i==0)continue;
this.waste[i].y=this.waste[Number(i)-1].y;
this.waste[i].x=this.waste[Number(i)-1].x;
}


//BEGIN: DRAW
for(let k=0;k<this.a.length;k++)
for(let i in this.a[k])
{
this.a[Number(k)][Number(i)][this.a[Number(k)][Number(i)].length-1].draw();
}



if(this.waste.length>0)
this.waste[0].draw();


//END: DRAW

for(let i in this.got)
{
this.got[i].draw(x-this.gx,y-this.gy);
}

this.lms=s;
};
//the most important function:end



won=function()
{
for(let i=0;i<25;i++)
{
if(this.a[Math.floor(i/5)][i%5].length>1)return false;
}
return true;
};
};
