class __Atta extends Game
{
constructor()
{
super();
let sup=new Supply();sup.load();
this.mode=0;
this.a=[];
for(let i=0;i<6;i++)
{
this.a.push([new CardForm(new Card(0),10+50*i,10,40,60,4)]);
}


let ccol=0;
let gc;

for(let i=0;i<4;i++)
{
for(let j=0;j<13;j++)
{
gc=sup.get();
this.a[i].push(new CardForm(gc,10+50*i,10,40,60,4));
}
}






/*new CardForm(new Card(0),10,10,40,60,4)];this.a.push(new CardForm(sup.get(),10,10,40,60,4));
this.b=[new CardForm(new Card(0),60,10,40,60,4)];this.b.push(new CardForm(sup.get(),60,10,40,60,4));*/

this.waste=[];

let getfs;

while((getfs=sup.get()))
{
if(getfs.cf==0)break;
this.waste.push(Object.assign({},new CardForm(getfs,10,10,40,60,4)));
}

this.got=[];
this.gx=0;this.gy=0;this.lms=false;


}


//The most imfortant function
manage=function(x,y,s)
{

let rb=false;
for(let i=0;i<1;i++)
if(s&&this.lms==false)
{

//////
//BEGIN: GETCARDS

for(let k=0;k<this.a.length;k++)
{rb=false;
for(let j=1;j<this.a[k].length;j++)
if(this.a[k][j].onit(x,y)&&this.got.length==0)
{
if(j+1<this.a[k].length)
{
if(this.a[k][j+1].onit(x,y))continue;
}
this.mode=k;
this.got.push(Object.assign({},this.a[k][j]))
if(j+1<this.a[k].length)
while(this.a[k][j].together(this.a[k][j+1]))
{
this.got.push(Object.assign({},this.a[k][j+1]));
this.a[k].splice(j,1);
//console.log(this.got);
if(j+1==this.a[k].length)break;
}
this.gx=x;this.gy=y;this.a[k].pop();rb=true;
}
else if(this.got.length!=0&&this.mode==k)
{
this.a[k].push(Object.assign({},this.got[0]));
this.got.splice(0,this.got.length);break;
}
if(rb)break;
}











//END: GETCARDS
//////




//////

}

for(let i=0;i<1;i++)
{
if(this.lms&&!s)//MOUSEUP
{
if(this.got.length==0)break;

/******/

//BEGIN: adding cards to a column
for(let k=0;k<this.a.length;k++)
if(this.a[k].length-1>=0)
if(this.a[k][this.a[k].length-1].onit(x,y))
{

if(this.a[k].length>1)
{
if(this.got[Number(i)].getsuit()!=this.a[k][this.a[k].length-1].getsuit())break;
}
if(this.a[k].length+this.got.length>14)break;

for(let i in this.got)
{
this.a[k].push(Object.assign({},this.got[i]));
}
this.got=[];break;
}




//END: adding cards to a column


/*******/

//END: giving back cards
for(let k=0;k<this.a.length;k++)
if(this.mode==k&&this.got.length!=0)
{
for(let j in this.got)
this.a[k].push(Object.assign({},this.got[Number(j)]));
this.got.splice(0,this.got.length);break;
}


//END: giving back cards


}

/********/


/*
if(this.got.length==0&&this.waste.length>0)
{

////

for(let k=0;k<this.a.length;k++)
if(this.a[k].length==1)
{
this.a[k].push(Object.assign({},new CardForm(this.waste[0],this.a[k][0].x,this.a[k][0].y,this.a[k][0].w,this.a[k][0].h,this.a[k][0].r)));
this.waste.shift();
}


////

}*/
}//END: MOUSEUP

if(this.got.length==0)
for(let i in this.a)
{
this.a[Number(i)][this.a[i].length-1].reveal();
}


let gotok=true;//Are taken cards OK?


for(let i in this.got)
{
if(this.got[Number(i)].ishidden()){gotok=false;break;}
if(Number(i)==0)continue;

if(this.got[Number(i)].getsuit()!=this.got[Number(i-1)].getsuit()){gotok=false;break;}
//if(this.got[Number(i)].getvalue()-this.got[Number(i-1)].getvalue()!=-1){gotok=false;break;}
}


if(!gotok)
{
for(let k=0;k<this.a.length;k++)
if(this.mode==k&&this.got.length!=0)
{
for(let j in this.got)
this.a[k].push(Object.assign({},this.got[Number(j)]));
this.got.splice(0,this.got.length);break;
}

}


/******/

//Correction
for(let j in this.a)
for(let i in this.a[j])
{
if(i==0)continue;
this.a[j][i].y=this.a[j][Number(i)-1].y+(i==1?0:20);
this.a[j][i].x=this.a[j][Number(i)-1].x;
}

for(let i=0;i<this.a.length;i++)
{
if(i==0){this.hightest=this.a[i].length;break;}
if(this.a[i].length>this.hightest)this.hightest=this.a[i].length;
}

for(let i=0;i<this.a.length;i++)
{
for(let j=2;j<this.a[i].length;j++)
{
if(this.a[i][j].getsuit()!=this.a[i][j-1].getsuit())break;
if(j==13)
{
this.a[i][j].hide();
}
}
}



for(let i in this.waste)
{
if(i==0)continue;
this.waste[i].y=this.waste[Number(i)-1].y;
this.waste[i].x=this.waste[Number(i)-1].x;
}


//BEGIN: DRAW
for(let k=0;k<this.a.length;k++)
for(let i in this.a[k])
{
this.a[Number(k)][Number(i)].draw();
}



if(this.waste.length>1)
this.waste[1].draw();

//END: DRAW

for(let i in this.got)
{
this.got[i].draw(x-this.gx,y-this.gy);
}



this.lms=s;
};
//the most important function:end



won=function()
{
for(let i=0;i<this.a.length;i++)
{
if(this.a[i].length!=14&&this.a[i].length!=1)return false;
for(let j=2;j<this.a[i].length;j++)
{
if(this.a[i][j].getsuit()!=this.a[i][j-1].getsuit())return false;
}
}
return true;
};
};
