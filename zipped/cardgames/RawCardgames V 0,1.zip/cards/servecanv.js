const canvas=document.getElementById("canvas");
const ctx=canvas.getContext("2d");

function draw_line(ctx,bx,by,ex,ey)
{
ctx.beginPath();
ctx.moveTo(bx,by);
ctx.lineTo(ex,ey);
ctx.stroke();
ctx.closePath();
}

function backgr(c,l)
{
ctx.fillStyle=c;
ctx.strokeStyle=l;
ctx.fillRect(0,0,canvas.width,canvas.height);
draw_line(ctx,0,0,100,200);
draw_line(ctx,800,10,100,200);
draw_line(ctx,1000,1000,600,200);
draw_line(ctx,0,940,600,200);
draw_line(ctx,570,920,100,200);
draw_line(ctx,0,620,100,200);
draw_line(ctx,570,920,600,200);
}
