function beforegame(ctx)
{
    ctx.font="40px verdana";
    ctx.fillStyle="black";
    ctx.fillText("SHIFT를 눌러 게임을 시작하세요.",0,40);
    ctx.fillText("Krzysztof Hrynkiewicz에게 인사드립니다.",0,908);
}

let allem=0,killed=0,appeareden=0;