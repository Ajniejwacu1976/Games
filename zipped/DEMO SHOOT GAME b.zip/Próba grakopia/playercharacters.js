let pltype;

const playertypes=
[
    '정상',
    '중력',
    '불꽃',
    '오르다',
    '즈테리',
    '바람',
]

function choose_character(ctx)
{
    ctx.font="40px verdana";
    ctx.fillStyle="black";
    ctx.fillText("캐릭터를 선택하세요:",40,80);

    for(i in playertypes)
    ctx.fillText(i+' '+playertypes[i],40,120+i*40);
}