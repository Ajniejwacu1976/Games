const canvas=document.getElementById("canvas");
const ctx=canvas.getContext("2d");
const Bricks=document.getElementById('bricks');
const Maciej=document.getElementById('boss');
const Flags=document.getElementsByClassName('imgfl');
const main=document.getElementById('maintheme');




let obst=[new Unit(0,858,2072,100,'ivory'),new Unit(0,758,100,100,'ivory'),new Unit(1972,758,100,100,'ivory')];
let player=new Player(0,10,40,40,'crimson',100,0,1,2,' ');
let camX=0,camY=0;let BW=2072;let BH=958;
let bord=[new Unit(BW,0,100,BH,"orange"),new Unit(0,BH,BW,100,"orange")];
let bullet=[];
let ienemy=[new Enemy(40,0,40,40,'chartreuse',100,1,0),new Enemy(40,0,40,40,'chartreuse',100,2,0),new Enemy(40,0,40,40,'chartreuse',100,3,0),new Enemy(40,0,40,40,'chartreuse',100,4,0)];
let enemy=[];
let ebullet=[];
let waitforenemy=400;let clvl=0;pltype=0;let gamestatus=-100;let pmhp=0;let menumode=0;let pressedesc=false;

let generate;

function go()
{
    //ctx.drawImage(iLib,-camX,-camY);
//console.log(main);


    for(let i=0;i<100;i++)
    for(let j=0;j<100;j++)
ctx.drawImage(Bricks,-camX+300*i,-camY+200*j);

if(gamestatus==-100){ctx.font="40px verdana";
ctx.fillStyle="black";
ctx.fillText("게임을 시작하려면 클릭하세요.",0,40);return;}

    if(gamestatus==-3){aftergame(ctx,clvl);main.pause();return;}
    if(gamestatus==-2)
    {
        beforegame(ctx);
        choose_character(ctx);
        for(let i=0;i<10;i++)
{
    if(presseds[getcharc(String(i))]==true)pltype=i;
}
        if(presseds[getcharc('SHIFT')]==true)
        {gamestatus=0;generate(0);}
        return;
    }


if(menumode==0)
waitforenemy--;
if(waitforenemy==0)
{
    waitforenemy=400;if(ienemy.length!=0)
    {
    enemy.push(ienemy[0]);
    appeareden++;
    ienemy.shift();
    }
}

if(enemy.length>allen)allen=enemy.length;


    if(player.x<1872/2)camX=0;
    else if(player.x>BW-1872/2)camX=BW-1872;
    else
    {
        camX=player.x-(1872)/2;
    }
    if(player.y<window.innerHeight/2)camY=0;
    else if(player.y>BH-window.innerHeight/2)camY=BH-window.innerHeight;
    else
    {
        camY=player.y-(window.innerHeight)/2;
    }
for(let i in obst)
obst[i].draw(camX,camY);
for(let i in bord)
bord[i].draw(camX,camY);




if((player.y>BH&&player.vy>0)||(player.y+player.h<-400))player.hp=0;



if(player.hp>0)
{
player.draw(camX,camY);
if(menumode==0){
player.move();
player.shoot(bullet);}
}
else
{
    defeat.play();
    gamestatus=-1;
    ctx.font="40px verdana";
    ctx.fillStyle="red";
    ctx.fillText("실패",800,40);
    player.w=0;player.h=0;
}
for(let i in obst)
{
    if(player.onright(obst[i])){player.pwr(obst[i]);player.whenright();}if(player.onleft(obst[i])){player.pwl(obst[i]);player.whenleft();}
    if(player.onup(obst[i])){player.pwu(obst[i]);player.whenup();}if(player.ondown(obst[i])){player.pwd(obst[i]);player.whendown();}
    if(player.incenter(obst[i]))player.whencent(obst[i]);
}


for(let i in obst)
{
    for(let j in bullet)
    {
if(bullet[j].onleft(obst[i])){bullet.splice(j,1);continue;}
if(bullet[j].onright(obst[i])){bullet.splice(j,1);continue;}
    }
}

for(let i in obst)
{
    for(let j in ebullet)
    {
if(ebullet[j].onleft(obst[i])&&!ebullet[j].hitimm){ebullet.splice(j,1);continue;}
if(ebullet[j].onright(obst[i])&&!ebullet[j].hitimm){ebullet.splice(j,1);continue;}
    }
}

for(let i in ebullet)
{
    ebullet[i].draw(camX,camY);if(menumode==0)ebullet[i].move();
    if(ebullet[i].incenter(player)){player.hp-=ebullet[i].str;ebullet.splice(i,1);}
}

for(let i in bullet)
{bullet[i].draw(camX,camY);if(menumode==0)bullet[i].move()}

for(let i in enemy)
{
    if(enemy[i].hp<=0||enemy[i].y>BH||enemy[i].y+enemy[i].h<0){enemy[i].dead();enemy.splice(i,1);killed++;continue;}
    enemy[i].draw(camX,camY);
    if(menumode==0){
    enemy[i].move();
    enemy[i].shoot(ebullet)}
}
for(let i in obst)
{
    for(let j in enemy)
    {
if(enemy[j].onleft(obst[i])){enemy[j].pwl(obst[i]);enemy[j].vx*=(-1);}
if(enemy[j].onright(obst[i])){enemy[j].pwr(obst[i]);enemy[j].vx*=(-1);}
if(enemy[j].onup(obst[i])){enemy[j].pwu(obst[i]);enemy[j].whenup();}
if(enemy[j].ondown(obst[i])){enemy[j].pwd(obst[i]);enemy[j].whendown();}
if(enemy[j].incenter(obst[i]))enemy[j].whencent(obst[i]);
    }
}

//main.play();

for(let j in enemy)
{
    for(let i in bullet)
    {
        if(
bullet[i].onright(enemy[j])||bullet[i].onleft(enemy[j])||bullet[i].incenter(enemy[j])
        )
        {
enemy[j].hp-=bullet[i].str;bullet.splice(i,1);
        }
    }
}



if(player.hp<0)player.hp=0;

ctx.font="40px verdana";
ctx.fillStyle="black";
ctx.fillText(country[clvl],20,40);




ctx.fillStyle='black';
ctx.fillRect(1700,20,120,10);
ctx.fillStyle='lime';
ctx.fillRect(1700,20,120*(appeareden/allen),10);
ctx.fillStyle='red';
ctx.fillRect(1700,20,120*(killed/allen),10);

ctx.fillStyle='black';
ctx.fillRect(1700,30,120,10);
ctx.fillStyle='red';
ctx.fillRect(1700,30,120*(player.hp/pmhp),10);

if(enemy.length==0&&ienemy.length==0&&player.hp>0)
{
    gamestatus=1;
    victory.play();
    ctx.font="40px verdana";
ctx.fillStyle="lime";
ctx.fillText("승리",800,40);
ctx.fillStyle="black";
ctx.fillText("죽인 적의 수: "+allen,1200,40);
choose_character(ctx);
for(let i=0;i<10;i++)
{
    if(presseds[getcharc(String(i))]==true)pltype=i;
}
}

if(!presseds[getcharc('ESCAPE')])pressedesc=false;
if(presseds[getcharc('ESCAPE')]&&!pressedesc)
{
    switch(menumode)
    {
        case 0:menumode=1;break;
        case 1:menumode=0;break;
        default:break;
    }
    pressedesc=true;
}


switch(menumode)
{
    case 1:choose_level(ctx,Flags);break;
    default:break;
}


if(presseds[getcharc('TAB')]&&gamestatus!=1)generate(clvl);
if(presseds[getcharc('SHIFT')]&&gamestatus==1)generate(++clvl);

ctx.fillStyle='#333';
ctx.fillRect(690,0,80,60);
ctx.drawImage(Flags[clvl],0,0,300,200,700,10,60,40);



}

window.setInterval(()=>{canvas.width=1872;canvas.height=window.innerHeight;if(gamestatus!=100)go()},1);


generate=function(lv)
{
    curr=lv;
    main.play();main.loop=true;
    victory.pause();defeat.pause();
victory.currentTime=0;defeat.currentTime=0;

    if(lvls[lv]==undefined){gamestatus=-3;return;}
    gamestatus=0;
    obst=[];
for(let i in lvls[lv].obst)
obst[i]=lvls[lv].obst[i];
while(ienemy.length>0)
ienemy.shift();
bullet=[];
for(let i in lvls[lv].ienemy)
{
ienemy.push(Object.create(lvls[lv].ienemy[i]));
}
BW=lvls[lv].bw;BH=lvls[lv].bh;
switch(pltype)
{
case 0:player=new Player(lvls[lv].hx,lvls[lv].hy,40,40,'crimson',100,0,1,2,' ');break;
case 1:player=new Grav(lvls[lv].hx,lvls[lv].hy,40,40,'red',100,0,1,2,3,' ');break;
case 2:player=new Spark(lvls[lv].hx,lvls[lv].hy,40,40,'coral',100,0,1,2,' ');break;
case 3:player=new Climber(lvls[lv].hx,lvls[lv].hy,40,40,'yellow',100,0,1,2,' ');break;
case 4:player=new Cztery(lvls[lv].hx,lvls[lv].hy,40,40,'silver',100,0,1,2,' ',enemy);break;
case 5:player=new Wind(lvls[lv].hx,lvls[lv].hy,40,40,'sienna',100,0,1,2,' ',enemy);break;
}
while(enemy.length>0)
enemy.shift();
waitforenemy=400;
ebullet=[];
bord=[new Unit(BW,0,100,BH,"orange"),new Unit(0,BH,BW,100,"orange")];
clvl=lv;
allen=ienemy.length;killed=0;appeareden=0;pmhp=player.hp;
}

canvas.onclick=function()
{
    if(gamestatus==-100)gamestatus=-2;
}

