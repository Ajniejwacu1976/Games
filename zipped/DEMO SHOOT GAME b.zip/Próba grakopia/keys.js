let gamekeys=[false,false,false,false];

function getcharc(a)
{
if(((a.charCodeAt(0)>64&&a.charCodeAt(0)<91)||(a.charCodeAt(0)>47&&a.charCodeAt(0)<58))&&a.length==1)
return a.charCodeAt(0);
switch(a)
{
    case 'BACKSPACE':return 8;
    case 'TAB':return 9;
    case 'SHIFT':return 16;
    case 'CONTROL':return 17;
    case 'ALT':case 'ALTGRAPH':return 18;
    case 'CAPSLOCK':return 20;
    case 'ESCAPE':return 27;
    case ' ':return 32;
}
}

let presseds=[];

for(let i=0;i<256;i++)
presseds[i]=false;









document.getElementsByTagName('body')[0].onkeydown=function()
{
switch(event.key)
{
    case 'ArrowLeft':gamekeys[0]=true;return;
    case 'ArrowRight':gamekeys[1]=true;return;
    case 'ArrowUp':gamekeys[2]=true;return;
    case 'ArrowDown':gamekeys[3]=true;return;
}
presseds[getcharc(event.key.toUpperCase())]=true;
}

document.getElementsByTagName('body')[0].onkeyup=function()
{
switch(event.key)
{
    case 'ArrowLeft':gamekeys[0]=false;return;
    case 'ArrowRight':gamekeys[1]=false;return;
    case 'ArrowUp':gamekeys[2]=false;return;
    case 'ArrowDown':gamekeys[3]=false;return;
}
presseds[getcharc(event.key.toUpperCase())]=false;
}