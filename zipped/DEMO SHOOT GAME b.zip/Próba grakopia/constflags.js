const FlagLabel=
[
    'PL','NE','DA','SE','BU','HU','UK','RO',
    'LI','LA','ES','GE','FI','SW','SL','CA',
    'FR','IT','GB','SA','IR','KZ','AF','JA',
    'KR','TH','VI','NK','CH','BE','RU','US',
];