let MK_l,MK_r,MK_u,MK_d;let curr=0;

function only_one()
{
    if(gamekeys[0])MK_l=true;
    if(!gamekeys[0])MK_l=false;
    if(gamekeys[1])MK_r=true;
    if(!gamekeys[1])MK_r=false;
    if(gamekeys[2])MK_u=true;
    if(!gamekeys[2])MK_u=false;
    if(gamekeys[3])MK_d=true;
    if(!gamekeys[3])MK_d=false;
}

function choose_level(ctx,Flags)
{
if(gamekeys[0]&&!MK_l&&curr>0)curr--;
if(gamekeys[1]&&!MK_r&&curr<32)curr++;
if(gamekeys[2]&&!MK_u&&curr>7)curr-=8;
if(gamekeys[3]&&!MK_d&&curr<25)curr+=8;

ctx.fillStyle="#444";
ctx.fillRect(20,300,640,300);
for(let i=0;i<4;i++)
{
    for(let j=0;j<8;j++)
    {
        ctx.fillStyle=(i*8+j==curr?"yellowgreen":"#222");
        ctx.fillRect(20+j*80,300+i*60,80,60);
        ctx.drawImage(Flags[i*8+j],0,0,300,200,30+j*80,310+i*60,60,40);
    }
    ctx.fillStyle=(32==curr?"yellowgreen":"#222");
    ctx.fillRect(20,540,80,60);
    ctx.drawImage(Maciej,0,0,300,200,30,550,60,40);

    if(presseds[getcharc('BACKSPACE')]){generate(curr);}
    ctx.font="40px verdana";
    ctx.fillStyle="black";
ctx.fillText(country[curr],120,584);
}
only_one();
}