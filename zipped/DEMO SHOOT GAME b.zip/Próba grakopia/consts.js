const
cPol=0,
cNet=1,
cDen=2,
cSer=3,
cBul=4,
cHun=5,
cUkr=6,
cRom=7,
cLit=8,
cLat=9,
cEst=10,
cGeo=11,
cFin=12,
cSwe=13,
cSvk=14,
cCan=15,
cFra=16,
cIta=17,
cGbr=18,
cSau=19,
cIrn=20,
cKzk=21,
cAph=22,
cJap=23,
cSko=24,
cTha=25,
cVie=26,
cNko=27,
cChi=28,
cBlr=29,
cRus=30,
cUsa=31,
Mac=32;


country=
[
    "폴란드","네덜란드","덴마크","세르비아",
    "불가리아","헝가리","우크라이나","루마니아",
    "리투아니아","라트비아","에스토니아","조지아",
    "핀란드","스웨덴","슬로바키아","캐나다",
    "프랑스","이탈리아","영국","사우디 아라비아",
    "이란","카자흐스탄","아프가니스탄","일본",
    "대한민국","태국","베트남","북한",
    "중국","벨라루스","러시아","미국",

    "Maciej 의 복수",
];



function pythagoras(fx,fy,lx,ly)
{
    return Math.sqrt(Math.pow(Math.abs(fx-lx),2)+Math.pow(Math.abs(fy-ly),2));
}

function randfrom(min,max)
{
    let base=Math.random()*max;
    if(base<min)return min;return base;
}


