function aftergame(ctx,lv)
{
    if(lv<33)
    {
    ctx.font="40px verdana";
    ctx.fillStyle="black";
    ctx.fillText('죄송합니다. 더 이상 레벨이 없습니다...',20,40);
    }
}