class Lvl
{
    constructor(obst,ienemy,bw,bh,hx,hy)
    {
        this.obst=obst;this.ienemy=ienemy;this.bw=bw;this.bh=bh;this.hx=hx;this.hy=hy;
    }
};

let lvls=[];
lvls=
[
new Lvl(
    [new Unit(0,858,1872,100),new Unit(0,758,100,100),new Unit(1772,758,100,100)],
    [new Enemy(40,0,40,40,'chartreuse',100,1,0),new Enemy(40,0,40,40,'chartreuse',100,2,0),new Enemy(40,0,40,40,'chartreuse',100,3,0),new Enemy(40,0,40,40,'chartreuse',100,4,0)],
    1872,958,10,10
    ),
    new Lvl(
        [new Unit(0,1772,1872,100),new Unit(200,758,1672,100),new Unit(0,100,1672,100),new Unit(0,0,10,1872),new Unit(1862,0,10,1872),new Unit(1562,1472,100,100)],
        [new Enemy(40,0,40,40,'chartreuse',100,1,0),new Enemy(40,0,40,40,'chartreuse',100,2,0),new Enemy(40,0,40,40,'chartreuse',100,3,0),new Enemy(40,0,40,40,'chartreuse',100,4,0)],
        1872,1872,1700,1700
        ),
        new Lvl(
            [new Unit(0,1772,1872,100),new Unit(1462,1272,100,100),new Unit(1562,1072,100,100),new Unit(0,0,10,1872),new Unit(1862,0,10,1872),new Unit(1562,1472,100,100)],
            [new Enemy(40,0,40,40,'chartreuse',100,1,0),new Enemy(40,0,40,40,'chartreuse',100,2,0),new Enemy(40,0,40,40,'chartreuse',100,3,0),new Enemy(40,0,40,40,'chartreuse',100,4,0)],
            1872,1872,1700,1700
            ),
            new Lvl(
                [new Unit(10,300,40,600),new Unit(10,300,300,40),new Unit(280,300,40,300),new Unit(10,560,300,40),
                new Unit(370,300,40,600),new Unit(370,300,300,40),new Unit(370,860,300,40),new Unit(670,300,40,600),
                new Unit(760,860,300,40),new Unit(760,300,40,600),
                new Unit(1110,560,40,340),new Unit(1110,560,300,40),
                new Unit(1370,300,40,600),new Unit(1150,300,260,40),new Unit(1150,300,40,300),
                new Unit(1460,300,40,600),new Unit(1590,300,40,600),
                new Unit(1460,560,190,40),new Unit(1590,300,100,40),new Unit(1590,860,130,40),
                new Unit(10,1200,40,600),new Unit(270,1200,40,600),new Unit(10,1760,300,40),new Unit(140,1540,40,260),
                new Unit(360,1200,40,600),new Unit(360,1200,300,40),new Unit(360,1760,300,40),new Unit(360,1460,300,40),new Unit(560,1800,40,80),
                new Unit(710,1200,40,600),new Unit(710,1200,300,40),new Unit(710,1760,300,40),new Unit(810,1540,200,40),new Unit(970,1540,40,260),
                new Unit(1060,1200,40,600),
                new Unit(1150,1200,40,600),new Unit(1150,1200,300,40),new Unit(1150,1760,300,40),new Unit(1150,1460,300,40),
                new Unit(1500,1200,40,600),new Unit(1500,1200,290,40),new Unit(1500,1500,300,40),new Unit(1750,1200,40,300),new Unit(1700,1500,40,300),new Unit(1700,1760,300,40),],
                
                [new Enemy(40,0,40,40,'chartreuse',50,1,0),new Enemy(40,0,40,40,'chartreuse',50,2,0),new Enemy(40,0,40,40,'chartreuse',50,3,0),new Enemy(40,0,40,40,'chartreuse',50,4,0)],
                1872,1872,10,10
                ),
        new Lvl(
            [new Unit(0,300,1870,20),new Unit(0,500,1870,20),new Unit(0,300,20,220),new Unit(1850,300,20,220)],
            [new Enemy(1800,400,60,60,'gold',1000,-4,0)],
            1872,958,40,400
        ),
        new Lvl(
            [new Unit(0,0,1872,40),new Unit(0,918,1872,40),new Unit(0,0,40,958),new Unit(1832,0,40,958),new Unit(200,200,1472,558),],
            [new Enemy(1800,400,60,60,'gold',1000,-4,0),new Enemy(1800,400,60,60,'gold',1000,-4,0),new Enemy(1800,400,60,60,'gold',1000,-4,0),new Enemy(1800,400,60,60,'gold',1000,-4,0)],
            1872,958,40,400
        ),
        new Lvl(
[new Unit(0,3000,1000,40),new Unit(200,200,40,2800),new Unit(2760,200,40,2800),new Unit(2000,3000,1000,40),
new Unit(1300,3000,400,40),new Unit(200,200,1000,40,),new Unit(400,500,2400,40,),new Unit(2600,2800,200,40),new Unit(400,400,40,100,),],
[new Enemy(2000,0,40,40,'chartreuse',200,-2,0)],
3000,3200,1400,2900
        ),
        new Lvl(
            [new Unit(0,2000,1920,40),new Unit(0,1960,40,80),new Unit(1880,1960,40,80),
            new Unit(0,0,1920,40),new Unit(760,200,400,1800),new Unit(660,1800,600,40),],
            [new Enemy(200,200,40,40,'blueviolet',10,1,1),new Enemy(1200,200,40,40,'blueviolet',10,-1,1),new Enemy(200,200,40,40,'blueviolet',10,1,1),new Enemy(1200,200,40,40,'blueviolet',10,-1,1),
            new Enemy(200,200,40,40,'blueviolet',10,1,1),new Enemy(1200,200,40,40,'blueviolet',10,-1,1),new Enemy(200,200,40,40,'blueviolet',10,1,1),new Enemy(1200,200,40,40,'blueviolet',10,-1,1),
            new Enemy(200,200,40,40,'blueviolet',10,1,1),new Enemy(1200,200,40,40,'blueviolet',10,-1,1),new Enemy(200,200,40,40,'blueviolet',10,1,1),new Enemy(1200,200,40,40,'blueviolet',10,-1,1),
            new Enemy(200,200,40,40,'blueviolet',10,1,1),new Enemy(1200,200,40,40,'blueviolet',10,-1,1),new Enemy(200,200,40,40,'blueviolet',10,1,1),new Enemy(1200,200,40,40,'blueviolet',10,-1,1),],
            1920,2040,926,100
        ),
        new Lvl(
[new Unit(0,0,2000,40),new Unit(0,0,40,2000),new Unit(0,1960,2000,40),
new Unit(1960,0,40,2000),new Unit(0,200,200,1600),new Unit(1800,200,200,1600),
new Unit(980,1100,40,900),new Unit(980,0,40,900),new Unit(600,800,40,40),
new Unit(600,1160,40,40),new Unit(1360,800,40,40),new Unit(1360,1160,40,40)],
[new Downup(1400,100,40,40,'chartreuse',600,-2,1),new Downup(1400,100,40,40,'chartreuse',600,2,1),new Downup(1400,100,40,40,'chartreuse',600,-2,1),new Downup(1400,100,40,40,'chartreuse',600,2,1),
new Downup(1400,100,40,40,'gold',200,-4,1),new Downup(1400,100,40,40,'gold',200,4,1),new Downup(1400,100,40,40,'gold',200,-4,1),new Downup(1400,100,40,40,'gold',200,4,1)],
2000,2000,100,100
        ),
        new Lvl(
            [new Unit(0,700,1000,20),new Unit(0,420,20,300),new Unit(980,690,20,10),new Unit(2100,700,200,20),new Unit(3200,600,1000,20),new Unit(4180,300,20,300),new Unit(3200,590,20,10),],
            [new Enemy(0,0,20,20,'chartreuse',100,2,2),new Enemy(0,0,40,40,'chartreuse',100,2,2),new Enemy(0,0,20,20,'chartreuse',100,2,2),new Enemy(0,0,40,40,'chartreuse',100,2,2),new Enemy(0,0,20,20,'chartreuse',100,2,2),new Enemy(0,0,40,40,'chartreuse',100,2,2),
            new Enemy(0,0,20,20,'chartreuse',100,2,2),new Enemy(0,0,20,20,'chartreuse',100,2,2),new Enemy(0,0,20,20,'chartreuse',100,2,2),new Enemy(0,0,20,20,'chartreuse',100,2,2),
            new Enemy(0,0,20,20,'chartreuse',100,2,2),new Enemy(0,0,20,20,'chartreuse',100,2,2),new Enemy(0,0,20,20,'chartreuse',100,2,2),new Enemy(0,0,20,20,'chartreuse',100,2,2),],
            4200,958,2200,0
        ),
        new Lvl(
            [new Unit(0,0,1872,40),new Unit(0,0,40,958),new Unit(1832,0,40,808),new Unit(0,918,1872,40),
                new Unit(200,478,1672,40),new Unit(0,719,100,239),new Unit(1772,239,100,239),new Unit(1872,958,1722,40),
                new Unit(1872,958,40,958),new Unit(1872,1876,1872,40),new Unit(3704,958,40,808),new Unit(2072,1436,1672,40),
                new Unit(1872,1675,100,239),new Unit(3644,1197,100,239),new Unit(3744,1916,40,958),new Unit(3744,1916,1672,40),
                new Unit(5576,1916,40,808),new Unit(3744,2834,1872,40),new Unit(5515,2155,100,239),new Unit(3944,2394,1672,40),
                new Unit(3744,2633,100,239),new Unit(5616,2874,1672,40),new Unit(5616,2874,40,958),new Unit(7448,2874,40,958),
                new Unit(5616,3792,1872,40),new Unit(7388,3113,100,239),new Unit(5616,3591,100,239),new Unit(5816,3352,1672,40),new Unit(4000,400,40,40),],
                [new Enemy(100,100,40,40,'chartreuse',100,2,2)],
                7488,3832,4000,0
        ),
        new Lvl(
            [new Unit(736,400,400,40),new Unit(736,360,40,80),new Unit(1096,360,40,80)],
            [new Enemy(936,300,40,40,'gold',1000,2,2)],
            1872,958,936,100
        ),
        new Lvl(
            [new Unit(100,400,200,40),new Unit(100,400,40,400),new Unit(100,760,200,40),new Unit(300,440,40,320),new Unit(400,400,40,400),new Unit(400,400,140,40),new Unit(500,400,40,400),new Unit(500,760,140,40),new Unit(600,400,40,400),new Unit(700,400,240,40),new Unit(700,580,240,40),new Unit(700,760,240,40),new Unit(700,400,40,180),new Unit(900,580,40,180),new Unit(1000,400,240,40),new Unit(1000,580,240,40),new Unit(1000,760,240,40),new Unit(1000,400,40,180),new Unit(1200,580,40,180),new Unit(300,1000,40,400),new Unit(300,1000,150,40),new Unit(300,1180,240,40),new Unit(300,1360,240,40),new Unit(410,1000,40,200),new Unit(500,1180,40,200),new Unit(600,1000,240,40),new Unit(600,1360,240,40),new Unit(700,1000,40,400),new Unit(900,1000,240,40),new Unit(900,1180,240,40),new Unit(900,1360,240,40),new Unit(900,1000,40,180),new Unit(1100,1180,40,180),new Unit(1200,1000,40,400),new Unit(1200,1000,240,40),new Unit(1200,1180,240,40),new Unit(1400,1000,40,200),new Unit(1320,1180,40,220),new Unit(1320,1360,120,40),new Unit(1300,760,240,40),new Unit(1300,560,40,200),new Unit(1500,560,40,200),],
            [new Obojniak(0,0,80,80,'gold',1000,2,2,enemy)],
            1872,2000,300,900
        ),
        new Lvl(
            [new Unit(669,0,100,2500),new Unit(1069,0,100,2500),new Unit(669,0,500,100),new Unit(869,200,100,100),new Unit(869,400,100,100),new Unit(869,600,100,100),new Unit(869,800,100,100),new Unit(869,1000,100,100),new Unit(869,1200,100,100),new Unit(869,1400,100,100),new Unit(869,1600,100,100),new Unit(869,1800,100,100),new Unit(869,2000,100,100),new Unit(869,2200,100,100),new Unit(669,2400,500,100),],
            [new Downup(880,100,40,40,'pink',1000,2,2)],
            1872,2500,880,2300
        ),
        new Lvl(
            [new Unit(0,0,1872,40),new Unit(0,0,40,958),new Unit(1832,0,40,958),new Unit(0,918,1872,40),new Unit(0,440,1500,40),new Unit(1672,658,200,300),new Unit(1460,400,40,40),],
            [new Aimer(40,40,40,40,'purple',1000,2,2,11.25,25)],
            1872,958,200,600
        ),
        new Lvl(
            [new Unit(0,129,4200,100),new Unit(0,729,4200,100),new Unit(0,129,100,700),new Unit(4100,129,100,700),new Unit(200,329,100,300),new Unit(3900,329,100,300),new Unit(400,429,100,100),new Unit(3700,429,100,100),new Unit(600,429,3000,100),new Unit(700,329,100,300),new Unit(3400,329,100,300),new Unit(900,229,100,100),new Unit(3200,229,100,100),new Unit(3200,629,100,100),new Unit(900,629,100,100),new Unit(2050,329,100,300),],
            [new Downup(4000,300,40,40,'pink',100,2,2),new Downup(4000,300,40,40,'pink',100,2,2),new Downup(4000,300,40,40,'pink',100,2,2),new Downup(4000,300,40,40,'pink',100,2,2),
            new Downup(4000,300,40,40,'pink',100,2,2),new Downup(4000,300,40,40,'pink',100,2,2),new Downup(4000,300,40,40,'pink',100,2,2),new Downup(4000,300,40,40,'pink',100,2,2),
            new Downup(4000,300,40,40,'pink',100,2,2),new Downup(4000,300,40,40,'pink',100,2,2),new Downup(4000,300,40,40,'pink',100,2,2),new Downup(4000,300,40,40,'pink',100,2,2),
            new Downup(4000,300,40,40,'pink',100,2,2),new Downup(4000,300,40,40,'pink',100,2,2),new Downup(4000,300,40,40,'pink',100,2,2),new Downup(4000,300,40,40,'pink',100,2,2),],
            4200,958,100,300
        ),
        new Lvl(
            [new Unit(0,400,850,40),new Unit(1022,400,850,40),new Unit(1832,360,40,40),new Unit(810,360,40,40),new Unit(1022,360,40,40),new Unit(0,360,40,40),new Unit(786,400,40,1600),new Unit(1046,400,40,1600),new Unit(0,1960,1872,40),new Unit(25,400,40,1600),new Unit(1812,400,40,1600),new Unit(826,1700,40,40),new Unit(1006,1500,40,40),new Unit(826,1300,40,40),new Unit(1006,1100,40,40),new Unit(826,900,40,40),new Unit(1006,700,40,40),],
            [new Aimer(40,40,40,40,'purple',1000,2,2,11.25,25),new Aimer(1832,40,40,40,'purple',1000,-2,2,11.25,25)],
            1872,2000,916,1920
        ),
        new Lvl(
            [new Unit(0,0,20,958),new Unit(3980,0,20,958),new Unit(0,500,4000,20)],
            [new Obojniak(20,0,80,80,'gold',1000,2,2,enemy),new Obojniak(3900,0,80,80,'gold',1000,-2,2,enemy)],
            4000,958,1980,100
        ),
        new Lvl(
            [new Unit(0,0,20,1872),new Unit(1852,0,20,1872),new Unit(0,1852,1872,20),new Unit(120,1552,1632,20),new Unit(0,1252,886,20),new Unit(986,1252,886,20),new Unit(120,952,1632,20),new Unit(0,652,886,20),new Unit(986,652,886,20),new Unit(120,352,1632,20),new Unit(0,0,1872,20),new Unit(120,932,20,20),new Unit(1732,932,20,20),new Unit(120,332,20,20),new Unit(1732,332,20,20),],
            [new Aimer(916,900,40,40,'purple',1000,2,2,11.25,25),new Enemy(916,20,40,40,'chartreuse',1000,2,2),new Enemy(916,20,40,40,'chartreuse',1000,-2,2),new Enemy(916,20,40,40,'chartreuse',1000,4,2),new Enemy(916,1720,40,40,'chartreuse',1000,-4,2),new Enemy(916,20,40,40,'chartreuse',1000,2,2),new Enemy(916,1720,40,40,'chartreuse',1000,-2,2),new Enemy(916,1720,40,40,'chartreuse',1000,4,2),new Enemy(916,1720,40,40,'chartreuse',1000,-4,2),],
            1872,1872,916,1812
        ),
        new Lvl(
            [new Unit(0,938,1872,20),new Unit(0,0,20,958),new Unit(1852,0,20,958),new Unit(100,200,1772,20),new Unit(0,100,1772,20),],
            [new Tangensoide(20,0,40,40,'blue',1000,2,2),new Tangensoide(20,0,40,40,'blue',1000,2,2),new Tangensoide(20,0,40,40,'blue',1000,2,2),new Tangensoide(20,0,40,40,'blue',1000,2,2),new Tangensoide(20,0,40,40,'blue',1000,2,2),new Tangensoide(20,0,40,40,'blue',1000,2,2),],
            1872,958,916,880
        ),
        new Lvl(
            [new Unit(0,0,2500,20),new Unit(0,0,20,2500),new Unit(500,2980,2500,20),new Unit(2980,500,20,2500),new Unit(600,2700,2400,20),new Unit(600,2500,2200,20),new Unit(700,2300,2100,20),new Unit(700,2100,2000,20),new Unit(800,1900,1900,20),new Unit(800,1700,1800,20),new Unit(900,1500,1700,20),new Unit(900,1300,1600,20),new Unit(1000,1100,1500,20),new Unit(1000,900,1400,20),new Unit(1100,700,1300,20),new Unit(1100,500,1200,20),new Unit(1200,300,1100,20),new Unit(2880,550,100,20),new Unit(2880,530,20,20),new Unit(1600,690,20,20),new Unit(1500,690,20,20),],
            [new Aimer(1560,660,40,40,'purple',1000,-2,0,11.25,25),new Obojniak(2900,470,80,80,'gold',1000,2,2,enemy,1,4)],
            3000,3000,1480,2940
        ),
        new Lvl(
            [new Unit(0,980,1872,20),new Unit(836,500,200,20),new Unit(1026,490,10,10),new Unit(836,490,10,10),new Unit(1272,750,200,20),new Unit(400,750,200,20),new Unit(836,140,10,10),new Unit(400,300,200,20),new Unit(1272,300,200,20),new Unit(736,150,400,20),new Unit(1026,140,10,10),],
            [new Aimer(916,400,40,40,'purple',2000,2,2,0.5,5),new Aimer(916,0,40,40,'purple',1000,2,2,22.5,25)],
            1872,1000,916,900
        ),
        new Lvl(
        [new Unit(0,0,40,958),new Unit(1832,0,40,958),new Unit(0,0,1872,40),new Unit(0,918,1872,40),new Unit(916,0,40,400),new Unit(916,558,40,400),new Unit(0,459,857,40),new Unit(1015,459,857,40),new Unit(450,279,40,400),new Unit(1382,279,40,400),new Unit(636,100,600,40),new Unit(636,818,600,40)],
        [new Tangensoide(40,40,40,40,'blue',1000,2,2),new Tangensoide(1792,40,40,40,'blue',1000,2,2),new Tangensoide(1792,878,40,40,'blue',1000,2,2),new Tangensoide(40,878,40,40,'blue',1000,2,2),
        new Tangensoide(40,40,40,40,'blue',1000,2,2),new Tangensoide(1792,40,40,40,'blue',1000,2,2),new Tangensoide(1792,878,40,40,'blue',1000,2,2),new Tangensoide(40,878,40,40,'blue',1000,2,2),
        new Tangensoide(40,40,40,40,'blue',1000,2,2),new Tangensoide(1792,40,40,40,'blue',1000,2,2),new Tangensoide(1792,878,40,40,'blue',1000,2,2),new Tangensoide(40,878,40,40,'blue',1000,2,2),
        new Tangensoide(40,40,40,40,'blue',1000,2,2),new Tangensoide(1792,40,40,40,'blue',1000,2,2),new Tangensoide(1792,878,40,40,'blue',1000,2,2),new Tangensoide(40,878,40,40,'blue',1000,2,2),],
        1872,958,40,40
        ),
        new Lvl(
            [new Unit(0,0,836,379),new Unit(1036,0,836,379),new Unit(1036,579,836,379),new Unit(0,579,836,379),new Unit(756,379,40,200),new Unit(1076,379,40,200),new Unit(836,299,200,40),new Unit(836,619,200,40),],
            [new Enemy(926,469,40,40,'mediumseagreen',4000,2,2)],
            1872,958,926,469
        ),
        new Lvl(
            [new Unit(40,410,40,200),new Unit(280,410,40,200),new Unit(80,370,200,40),new Unit(80,610,200,40),new Unit(360,300,40,400),new Unit(400,480,160,40),new Unit(40,800,520,40),new Unit(40,760,40,40),new Unit(600,300,40,200),new Unit(600,460,240,40),new Unit(880,500,200,40),new Unit(880,360,200,40),new Unit(1040,300,40,300),new Unit(920,620,40,180),new Unit(700,620,40,180),new Unit(740,580,180,40),new Unit(740,800,180,40),new Unit(1340,560,40,180),new Unit(1120,560,40,180),new Unit(1160,520,180,40),new Unit(1160,740,180,40),new Unit(1120,440,260,40),new Unit(1230,400,40,40),new Unit(1460,300,40,540),new Unit(1460,540,200,40),new Unit(1800,300,40,240),new Unit(1900,540,40,300),new Unit(1700,540,40,300),new Unit(1700,540,200,40),new Unit(1980,540,80,40),new Unit(2060,300,40,540),new Unit(2140,300,40,540),new Unit(2360,380,40,180),new Unit(2580,380,40,180),new Unit(2400,560,180,40),new Unit(2400,340,180,40),new Unit(2320,660,40,100),new Unit(2620,660,40,100),new Unit(2220,760,540,40)],
            [],
            2800,958,100,0
        ),
        new Lvl(
            [new Unit(0,0,20,958),new Unit(1852,0,20,958),new Unit(0,0,1872,20),new Unit(0,938,1872,20),new Unit(966,700,700,100),new Unit(206,700,700,100),new Unit(206,200,700,100),new Unit(966,200,700,100),new Unit(1752,450,100,100),new Unit(20,450,100,100),new Unit(0,0,200,130),new Unit(1672,0,200,130)],
            [new Obojniak(200,20,80,80,'gold',2000,2,2,enemy)],
            1872,958,916,20
        ),
        new Lvl(
            [new Unit(1960,0,40,2000),new Unit(0,0,40,2000),new Unit(0,0,2000,40),new Unit(0,1960,2000,40),new Unit(600,0,40,1500),new Unit(1360,0,40,1500),new Unit(420,1460,400,40),new Unit(1180,1460,400,40)],
            [new Downup(980,60,40,40,'gold',500,2,2),new Downup(980,60,40,40,'gold',500,2,2),new Downup(980,60,40,40,'gold',500,2,2),new Downup(980,60,40,40,'gold',500,2,2),
            new Downup(980,60,40,40,'gold',500,2,2),new Downup(980,60,40,40,'gold',500,2,2),new Downup(980,60,40,40,'gold',500,2,2),new Downup(980,60,40,40,'gold',500,2,2),
            new Downup(980,60,40,40,'gold',500,2,2),new Downup(980,60,40,40,'gold',500,2,2),new Downup(980,60,40,40,'gold',500,2,2),new Downup(980,60,40,40,'gold',500,2,2),
            new Downup(980,60,40,40,'gold',500,2,2),new Downup(980,60,40,40,'gold',500,2,2),new Downup(980,60,40,40,'gold',500,2,2),new Downup(980,60,40,40,'gold',500,2,2),],
            2000,2000,980,100
        ),
        new Lvl(
            [new Unit(0,900,20,20),new Unit(1920,900,20,20),new Unit(40,920,20,20),new Unit(120,920,20,20),new Unit(200,920,20,20),new Unit(280,920,20,20),new Unit(360,920,20,20),new Unit(440,920,20,20),new Unit(520,920,20,20),new Unit(600,920,20,20),new Unit(680,920,20,20),new Unit(760,920,20,20),new Unit(840,920,20,20),new Unit(920,920,20,20),new Unit(1000,920,20,20),new Unit(1080,920,20,20),new Unit(1160,920,20,20),new Unit(1240,920,20,20),new Unit(1320,920,20,20),new Unit(1400,920,20,20),new Unit(1480,920,20,20),new Unit(1560,920,20,20),new Unit(1640,920,20,20),new Unit(1720,920,20,20),new Unit(1800,920,20,20),new Unit(1880,920,20,20)],
            [new Obojniak(0,0,80,80,'gold',5000,2,2,enemy)],
            1940,958,1900,0
        ),
        new Lvl(
            [new Unit(0,0,100,958),new Unit(1772,0,100,958),new Unit(0,0,1872,100),new Unit(0,858,1872,100)],
            [new Enemy(1692,100,80,80,'chartreuse',1000,2,2,function(){enemy.push(new Downup(this.x,this.y,80,80,'gold',1000,2,2));killeden.play();appeareden++;allen++;})],
            1872,958,100,100
        ),
        new Lvl(
            [new Unit(686,0,100,2700),new Unit(1086,0,100,2700),new Unit(686,0,500,100),new Unit(836,200,200,100),new Unit(786,400,100,100),new Unit(986,400,100,100),new Unit(886,600,100,100),new Unit(786,800,100,100),new Unit(986,800,100,100),new Unit(886,1000,100,100),new Unit(786,1200,100,100),new Unit(986,1200,100,100),new Unit(886,1400,100,100),new Unit(786,1600,100,100),new Unit(986,1600,100,100),new Unit(886,1800,100,100),new Unit(786,2000,100,100),new Unit(986,2000,100,100),new Unit(886,2200,100,100),new Unit(786,2400,100,100),new Unit(986,2400,100,100),new Unit(886,2600,100,100)],
            [new Obojniak(896,100,80,80,'gold',2000,2,2,enemy)],
            1872,2700,916,2500
        ),
        new Lvl(
            [new Unit(0,50,20,700),new Unit(3980,50,20,700),new Unit(0,600,4000,20),new Unit(90,500,3820,20),new Unit(1990,460,20,20)],
            [new Obojniak(0,0,80,80,'gold',500,2,2,enemy),new Obojniak(3920,0,80,80,'gold',500,-2,2,enemy),
            new Enemy(0,0,40,40,'chartreuse',100,2,2),new Enemy(3960,0,40,40,'chartreuse',100,-2,2),
            new Obojniak(0,0,80,80,'gold',500,2,2,enemy),new Obojniak(3920,0,80,80,'gold',500,-2,2,enemy)],
            4000,958,1980,500
        ),
        new Lvl(
            [new Unit(1772,0,100,958),new Unit(0,0,100,958),new Unit(0,858,1872,100),new Unit(0,0,1872,100),new Unit(846,848,40,40),new Unit(986,848,40,40),new Unit(1272,600,100,100),new Unit(500,600,100,100),new Unit(886,400,100,100)],
            [new Enemy(1692,100,40,40,'chartreuse',1000,2,2,function(){enemy.push(new Downup(this.x,this.y,40,40,'gold',1000,2,2));killeden.play();appeareden++;allen++;}),
            new Enemy(160,100,40,40,'chartreuse',1000,2,2,function(){enemy.push(new Downup(this.x,this.y,40,40,'gold',1000,-2,2));killeden.play();appeareden++;allen++;}),
            new Enemy(1692,100,40,40,'chartreuse',1000,2,2,function(){enemy.push(new Downup(this.x,this.y,40,40,'gold',1000,2,2));killeden.play();appeareden++;allen++;}),
            new Enemy(160,100,40,40,'chartreuse',1000,2,2,function(){enemy.push(new Downup(this.x,this.y,40,40,'gold',1000,-2,2));killeden.play();appeareden++;allen++;}),
        new Aimer(916,800,40,40,'pruple',1000,1,1,0.5,5),new Tangensoide(916,800,40,40,'blue',1000,-1,1)],
            1872,958,916,800
        ),
];
